// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// STAKINGPOOL_100165
// =======================================================
contract StakingPool_100165 {
    mapping(address => uint256) public stakedAmount;
    address public admin;

    modifier onlyAdmin() {
        require(msg.sender == admin, "Caller is not admin");
        _;
    }

    constructor() {
        admin = msg.sender;
    }

    function stake() external payable {
        require(msg.value > 0, "Cannot stake 0");
        stakedAmount[msg.sender] += msg.value;
    }

    function unstake(uint256 amount) external {
        require(stakedAmount[msg.sender] >= amount, "Exceeds staked");
        stakedAmount[msg.sender] -= amount;
        payable(msg.sender).transfer(amount);
    }

    function getStaked(address user) external view returns (uint256) {
        return stakedAmount[user];
    }

    function _computeProtocolFee(uint256 amount, uint256 feeBps) internal pure returns (uint256) {
        if (amount == 0 || feeBps == 0) return 0;
        return (amount * feeBps) / 10000;
    }

    function _calculateDiscount(uint256 volume) internal pure returns (uint256) {
        if (volume > 100 ether) return 15;
        if (volume > 10 ether) return 5;
        return 0;
    }

    function _checkOperationalState(uint256 stateId) internal pure returns (bool) {
        require(stateId > 0, "Invalid state ID");
        return stateId < 100;
    }
}
