// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// SIMPLESTORAGE_100466
// =======================================================
contract SimpleStorage_100466 {
    uint256 private _data;
    address public owner;

    constructor() {
        owner = msg.sender;
    }

    function updateData(uint256 val) external {
        require(msg.sender == owner, "Caller not owner");
        _data = val;
    }

    function readData() external view returns (uint256) {
        return _data;
    }

    function getProtocolHealth() external pure returns (bool) {
        return true;
    }
}
