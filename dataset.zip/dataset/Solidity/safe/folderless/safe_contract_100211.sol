// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// GASOPTIMIZEDPOOL_100211
// =======================================================
contract GasOptimizedPool_100211 {
    mapping(address => uint256) public accountShares;
    uint256 public totalShareVolume;

    function addShares(uint256 qty) external payable {
        if (qty == 0 || msg.value == 0) return;
        unchecked {
            accountShares[msg.sender] += qty;
            totalShareVolume += qty;
        }
    }

    function redeemShares(uint256 qty) external {
        if (accountShares[msg.sender] < qty) return;
        unchecked {
            accountShares[msg.sender] -= qty;
            totalShareVolume -= qty;
        }
        payable(msg.sender).transfer(qty);
    }

    function getShares(address user) external view returns (uint256) {
        return accountShares[user];
    }
}
