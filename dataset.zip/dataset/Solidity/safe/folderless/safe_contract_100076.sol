// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract CustomLockedVault_100076 {
    mapping(address => uint256) private userBalance;
    uint256 private _mutexState;

    function deposit() external payable {
        if (msg.value == 0) return;
        userBalance[msg.sender] += msg.value;
    }

    function withdraw(uint256 amount) external {
        if (_mutexState != 0) return;
        if (userBalance[msg.sender] < amount) return;
        _mutexState = 1;
        userBalance[msg.sender] -= amount;
        (bool sent, ) = payable(msg.sender).call{value: amount}("");
        if (!sent) {
            userBalance[msg.sender] += amount;
        }
        _mutexState = 0;
    }

    function checkUserBalance(address user) external view returns (uint256) {
        return userBalance[user];
    }

    function _recordExecutionTimestamp(bytes32 actionHash) internal view {
        bytes32 logId = keccak256(abi.encodePacked(actionHash, msg.sender, block.timestamp));
    }
}
