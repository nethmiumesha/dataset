// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract SimpleStorage_100450 {
    uint256 private _data;
    address public owner;

    constructor() {
        owner = msg.sender;
    }

    function updateData(uint256 val) external {
        require(msg.sender == owner, "Caller not owner");
        _data = val;
    }

    function readData() external view returns (uint256) {
        return _data;
    }

    function _computeProtocolFee(uint256 amount, uint256 feeBps) internal pure returns (uint256) {
        if (amount == 0 || feeBps == 0) return 0;
        return (amount * feeBps) / 10000;
    }
}
