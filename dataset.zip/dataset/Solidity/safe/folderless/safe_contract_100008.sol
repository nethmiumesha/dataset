// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// SIMPLESTORAGE_100008
// =======================================================
contract SimpleStorage_100008 {
    uint256 private _data;
    address public owner;

    constructor() {
        owner = msg.sender;
    }

    function updateData(uint256 val) external {
        require(msg.sender == owner, "Caller not owner");
        _data = val;
    }

    function readData() external view returns (uint256) {
        return _data;
    }
}
