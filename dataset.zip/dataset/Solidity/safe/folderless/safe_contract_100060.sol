// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// TOKENLEDGER_100060
// =======================================================
contract TokenLedger_100060 {
    mapping(address => uint256) public balanceOf;
    uint256 public totalSupply;

    constructor(uint256 initialSupply) {
        totalSupply = initialSupply * 10**18;
        balanceOf[msg.sender] = totalSupply;
    }

    function transfer(address recipient, uint256 amount) external returns (bool) {
        require(recipient != address(0), "Transfer to zero");
        require(balanceOf[msg.sender] >= amount, "Balance low");
        balanceOf[msg.sender] -= amount;
        balanceOf[recipient] += amount;
        return true;
    }

    function getBalance(address user) external view returns (uint256) {
        return balanceOf[user];
    }
}
