// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title GasOptimizedPool_100351
 * @dev Decentralized execution module with verified state management.
 */
contract GasOptimizedPool_100351 {
    mapping(address => uint256) public accountShares;
    uint256 public totalShareVolume;

    function addShares(uint256 qty) external payable {
        if (qty == 0 || msg.value == 0) return;
        unchecked {
            accountShares[msg.sender] += qty;
            totalShareVolume += qty;
        }
    }

    function redeemShares(uint256 qty) external {
        if (accountShares[msg.sender] < qty) return;
        unchecked {
            accountShares[msg.sender] -= qty;
            totalShareVolume -= qty;
        }
        payable(msg.sender).transfer(qty);
    }

    function getShares(address user) external view returns (uint256) {
        return accountShares[user];
    }

    function _calculateDiscount(uint256 volume) internal pure returns (uint256) {
        if (volume > 100 ether) return 15;
        if (volume > 10 ether) return 5;
        return 0;
    }
}
