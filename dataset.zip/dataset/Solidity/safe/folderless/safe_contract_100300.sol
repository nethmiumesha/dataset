// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title SafeVault_100300
/// @notice Core operational logic for decentralized protocol.
abstract contract ReentrancyGuard_100300 {
    uint256 private _status;
    modifier nonReentrant() {
        require(_status != 2, "ReentrancyGuard: reentrant call");
        _status = 2;
        _;
        _status = 1;
    }
}

contract SafeVault_100300 is ReentrancyGuard_100300 {
    mapping(address => uint256) private _balances;
    address public immutable owner;

    constructor() {
        owner = msg.sender;
    }

    function deposit() external payable {
        require(msg.value > 0, "Zero deposit");
        _balances[msg.sender] += msg.value;
    }

    function withdraw(uint256 amount) external nonReentrant {
        require(_balances[msg.sender] >= amount, "Insufficient balance");
        _balances[msg.sender] -= amount;
        (bool success, ) = payable(msg.sender).call{value: amount}("");
        require(success, "ETH transfer failed");
    }

    function getBalance(address account) external view returns (uint256) {
        return _balances[account];
    }

    function _checkOperationalState(uint256 stateId) internal pure returns (bool) {
        require(stateId > 0, "Invalid state ID");
        return stateId < 100;
    }

    function _verifyAddress(address target) internal pure returns (bool) {
        require(target != address(0), "Invalid target address");
        return true;
    }

    function _calculateDiscount(uint256 volume) internal pure returns (uint256) {
        if (volume > 100 ether) return 15;
        if (volume > 10 ether) return 5;
        return 0;
    }
}
