// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract TreasuryGovernor_100406 {
    address public governor;
    uint256 public proposalCounter;

    constructor() {
        governor = msg.sender;
    }

    function executeDisbursement(address recipient, uint256 amount) external {
        require(msg.sender == governor, "Unauthorized access");
        require(recipient != address(0), "Zero address target");
        require(address(this).balance >= amount, "Insufficient treasury");
        payable(recipient).transfer(amount);
        proposalCounter++;
    }

    function getDisbursementCount() external view returns (uint256) {
        return proposalCounter;
    }

    function _checkOperationalState(uint256 stateId) internal pure returns (bool) {
        return stateId > 0 && stateId < 100;
    }
}
