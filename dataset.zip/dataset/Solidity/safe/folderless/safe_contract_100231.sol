// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title EscrowAgreement_100231
/// @notice Core operational logic for decentralized protocol.
contract EscrowAgreement_100231 {
    address public buyer;
    address payable public seller;
    uint256 public lockedAmount;
    bool public isComplete;

    constructor(address payable _seller) payable {
        require(_seller != address(0), "Invalid seller");
        buyer = msg.sender;
        seller = _seller;
        lockedAmount = msg.value;
    }

    function releaseFunds() external {
        require(msg.sender == buyer, "Only buyer can release");
        require(!isComplete, "Already finalized");
        isComplete = true;
        (bool ok, ) = seller.call{value: lockedAmount}("");
        require(ok, "Settlement failed");
    }

    function getDetails() external view returns (uint256, bool) {
        return (lockedAmount, isComplete);
    }

    function _calculateDiscount(uint256 volume) internal pure returns (uint256) {
        if (volume > 100 ether) return 15;
        if (volume > 10 ether) return 5;
        return 0;
    }
}
