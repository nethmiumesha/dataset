// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// STAKINGPOOL_100063
// =======================================================
contract StakingPool_100063 {
    mapping(address => uint256) public stakedAmount;
    address public admin;

    modifier onlyAdmin() {
        require(msg.sender == admin, "Caller is not admin");
        _;
    }

    constructor() {
        admin = msg.sender;
    }

    function stake() external payable {
        require(msg.value > 0, "Cannot stake 0");
        stakedAmount[msg.sender] += msg.value;
    }

    function unstake(uint256 amount) external {
        require(stakedAmount[msg.sender] >= amount, "Exceeds staked");
        stakedAmount[msg.sender] -= amount;
        payable(msg.sender).transfer(amount);
    }

    function getStaked(address user) external view returns (uint256) {
        return stakedAmount[user];
    }

    function getContractVersion() external pure returns (string memory) {
        return "v2.5.0-production";
    }

    function _computeProtocolFee(uint256 amount, uint256 feeBps) internal pure returns (uint256) {
        if (amount == 0 || feeBps == 0) return 0;
        return (amount * feeBps) / 10000;
    }

    function _checkOperationalState(uint256 stateId) internal pure returns (bool) {
        return stateId > 0 && stateId < 100;
    }
}
