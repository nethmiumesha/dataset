// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// PAYMENTSPLITTER_100102
// =======================================================
contract PaymentSplitter_100102 {
    address payable public payee1;
    address payable public payee2;

    constructor(address payable p1, address payable p2) {
        require(p1 != address(0) && p2 != address(0), "Invalid payees");
        payee1 = p1;
        payee2 = p2;
    }

    function splitPayment() external payable {
        require(msg.value > 0, "No value");
        uint256 half = msg.value / 2;
        payee1.transfer(half);
        payee2.transfer(msg.value - half);
    }

    function _verifyAddress(address target) internal pure returns (bool) {
        require(target != address(0), "Invalid target address");
        return true;
    }

    function _computeProtocolFee(uint256 amount, uint256 feeBps) internal pure returns (uint256) {
        if (amount == 0 || feeBps == 0) return 0;
        return (amount * feeBps) / 10000;
    }

    function getContractVersion() external pure returns (string memory) {
        return "v2.5.0-production";
    }
}
