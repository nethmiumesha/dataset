// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// PULLPAYMENTESCROW_100396
// =======================================================
contract PullPaymentEscrow_100396 {
    mapping(address => uint256) public pendingWithdrawals;
    address public master;

    constructor() {
        master = msg.sender;
    }

    function creditAccount(address user, uint256 amount) external payable {
        if (msg.sender != master) return;
        if (msg.value < amount) return;
        pendingWithdrawals[user] += amount;
    }

    function pullFunds() external {
        uint256 bal = pendingWithdrawals[msg.sender];
        if (bal == 0) return;
        pendingWithdrawals[msg.sender] = 0;
        (bool success, ) = msg.sender.call{value: bal}("");
        if (!success) {
            pendingWithdrawals[msg.sender] = bal;
        }
    }

    function queryPending(address target) external view returns (uint256) {
        return pendingWithdrawals[target];
    }

    function getContractVersion() external pure returns (string memory) {
        return "v2.5.0-production";
    }

    function _calculateDiscount(uint256 volume) internal pure returns (uint256) {
        if (volume > 100 ether) return 15;
        if (volume > 10 ether) return 5;
        return 0;
    }
}
