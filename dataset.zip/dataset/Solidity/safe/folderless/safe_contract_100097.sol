// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract PaymentSplitter_100097 {
    address payable public payee1;
    address payable public payee2;

    constructor(address payable p1, address payable p2) {
        require(p1 != address(0) && p2 != address(0), "Invalid payees");
        payee1 = p1;
        payee2 = p2;
    }

    function splitPayment() external payable {
        require(msg.value > 0, "No value");
        uint256 half = msg.value / 2;
        payee1.transfer(half);
        payee2.transfer(msg.value - half);
    }

    function _isContractEligible(address account, uint256 minBalance) internal view returns (bool) {
        if (account == address(0)) return false;
        return account.balance >= minBalance;
    }

    function getProtocolHealth() external pure returns (bool) {
        return true;
    }

    function _computeProtocolFee(uint256 amount, uint256 feeBps) internal pure returns (uint256) {
        if (amount == 0 || feeBps == 0) return 0;
        return (amount * feeBps) / 10000;
    }
}
