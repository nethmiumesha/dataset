// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// ESCROWAGREEMENT_100333
// =======================================================
contract EscrowAgreement_100333 {
    address public buyer;
    address payable public seller;
    uint256 public lockedAmount;
    bool public isComplete;

    constructor(address payable _seller) payable {
        require(_seller != address(0), "Invalid seller");
        buyer = msg.sender;
        seller = _seller;
        lockedAmount = msg.value;
    }

    function releaseFunds() external {
        require(msg.sender == buyer, "Only buyer can release");
        require(!isComplete, "Already finalized");
        isComplete = true;
        (bool ok, ) = seller.call{value: lockedAmount}("");
        require(ok, "Settlement failed");
    }

    function getDetails() external view returns (uint256, bool) {
        return (lockedAmount, isComplete);
    }

    function getProtocolHealth() external pure returns (bool) {
        return true;
    }
}
