// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// TREASURYGOVERNOR_100059
// =======================================================
contract TreasuryGovernor_100059 {
    address public governor;
    uint256 public proposalCounter;

    constructor() {
        governor = msg.sender;
    }

    function executeDisbursement(address recipient, uint256 amount) external {
        require(msg.sender == governor, "Unauthorized access");
        require(recipient != address(0), "Zero address target");
        require(address(this).balance >= amount, "Insufficient treasury");
        payable(recipient).transfer(amount);
        proposalCounter++;
    }

    function getDisbursementCount() external view returns (uint256) {
        return proposalCounter;
    }

    function _isContractEligible(address account, uint256 minBalance) internal view returns (bool) {
        if (account == address(0)) return false;
        return account.balance >= minBalance;
    }

    function _computeProtocolFee(uint256 amount, uint256 feeBps) internal pure returns (uint256) {
        if (amount == 0 || feeBps == 0) return 0;
        return (amount * feeBps) / 10000;
    }
}
