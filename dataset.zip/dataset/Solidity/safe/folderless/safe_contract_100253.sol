// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract TreasuryGovernor_100253 {
    address public governor;
    uint256 public proposalCounter;

    constructor() {
        governor = msg.sender;
    }

    function executeDisbursement(address recipient, uint256 amount) external {
        require(msg.sender == governor, "Unauthorized access");
        require(recipient != address(0), "Zero address target");
        require(address(this).balance >= amount, "Insufficient treasury");
        payable(recipient).transfer(amount);
        proposalCounter++;
    }

    function getDisbursementCount() external view returns (uint256) {
        return proposalCounter;
    }

    function _computeProtocolFee(uint256 amount, uint256 feeBps) internal pure returns (uint256) {
        if (amount == 0 || feeBps == 0) return 0;
        return (amount * feeBps) / 10000;
    }

    function getContractVersion() external pure returns (string memory) {
        return "v2.5.0-production";
    }
}
