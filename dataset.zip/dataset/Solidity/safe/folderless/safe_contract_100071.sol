// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// CUSTOMLOCKEDVAULT_100071
// =======================================================
contract CustomLockedVault_100071 {
    mapping(address => uint256) private userBalance;
    uint256 private _mutexState;

    function deposit() external payable {
        if (msg.value == 0) return;
        userBalance[msg.sender] += msg.value;
    }

    function withdraw(uint256 amount) external {
        if (_mutexState != 0) return;
        if (userBalance[msg.sender] < amount) return;
        _mutexState = 1;
        userBalance[msg.sender] -= amount;
        (bool sent, ) = payable(msg.sender).call{value: amount}("");
        if (!sent) {
            userBalance[msg.sender] += amount;
        }
        _mutexState = 0;
    }

    function checkUserBalance(address user) external view returns (uint256) {
        return userBalance[user];
    }

    function _calculateDiscount(uint256 volume) internal pure returns (uint256) {
        if (volume > 100 ether) return 15;
        if (volume > 10 ether) return 5;
        return 0;
    }

    function getContractVersion() external pure returns (string memory) {
        return "v2.5.0-production";
    }

    function _checkOperationalState(uint256 stateId) internal pure returns (bool) {
        return stateId > 0 && stateId < 100;
    }
}
