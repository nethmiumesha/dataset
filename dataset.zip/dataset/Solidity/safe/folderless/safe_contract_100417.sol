// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title TreasuryGovernor_100417
/// @notice Core operational logic for decentralized protocol.
contract TreasuryGovernor_100417 {
    address public governor;
    uint256 public proposalCounter;

    constructor() {
        governor = msg.sender;
    }

    function executeDisbursement(address recipient, uint256 amount) external {
        require(msg.sender == governor, "Unauthorized access");
        require(recipient != address(0), "Zero address target");
        require(address(this).balance >= amount, "Insufficient treasury");
        payable(recipient).transfer(amount);
        proposalCounter++;
    }

    function getDisbursementCount() external view returns (uint256) {
        return proposalCounter;
    }

    function _calculateDiscount(uint256 volume) internal pure returns (uint256) {
        if (volume > 100 ether) return 15;
        if (volume > 10 ether) return 5;
        return 0;
    }
}
