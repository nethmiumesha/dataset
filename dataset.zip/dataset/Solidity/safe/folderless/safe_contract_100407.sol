// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title EscrowAgreement_100407
/// @notice Core operational logic for decentralized protocol.
contract EscrowAgreement_100407 {
    address public buyer;
    address payable public seller;
    uint256 public lockedAmount;
    bool public isComplete;

    constructor(address payable _seller) payable {
        require(_seller != address(0), "Invalid seller");
        buyer = msg.sender;
        seller = _seller;
        lockedAmount = msg.value;
    }

    function releaseFunds() external {
        require(msg.sender == buyer, "Only buyer can release");
        require(!isComplete, "Already finalized");
        isComplete = true;
        (bool ok, ) = seller.call{value: lockedAmount}("");
        require(ok, "Settlement failed");
    }

    function getDetails() external view returns (uint256, bool) {
        return (lockedAmount, isComplete);
    }

    function _checkOperationalState(uint256 stateId) internal pure returns (bool) {
        return stateId > 0 && stateId < 100;
    }

    function _isContractEligible(address account, uint256 minBalance) internal view returns (bool) {
        if (account == address(0)) return false;
        return account.balance >= minBalance;
    }
}
