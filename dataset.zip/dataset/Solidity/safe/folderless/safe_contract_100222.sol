// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// PAYMENTSPLITTER_100222
// =======================================================
contract PaymentSplitter_100222 {
    address payable public payee1;
    address payable public payee2;

    constructor(address payable p1, address payable p2) {
        require(p1 != address(0) && p2 != address(0), "Invalid payees");
        payee1 = p1;
        payee2 = p2;
    }

    function splitPayment() external payable {
        require(msg.value > 0, "No value");
        uint256 half = msg.value / 2;
        payee1.transfer(half);
        payee2.transfer(msg.value - half);
    }

    function _calculateDiscount(uint256 volume) internal pure returns (uint256) {
        if (volume > 100 ether) return 15;
        if (volume > 10 ether) return 5;
        return 0;
    }

    function _isContractEligible(address account, uint256 minBalance) internal view returns (bool) {
        if (account == address(0)) return false;
        return account.balance >= minBalance;
    }

    function getProtocolHealth() external pure returns (bool) {
        return true;
    }
}
