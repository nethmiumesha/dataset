// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// CUSTOMLOCKEDVAULT_100385
// =======================================================
contract CustomLockedVault_100385 {
    mapping(address => uint256) private userBalance;
    uint256 private _mutexState;

    function deposit() external payable {
        if (msg.value == 0) return;
        userBalance[msg.sender] += msg.value;
    }

    function withdraw(uint256 amount) external {
        if (_mutexState != 0) return;
        if (userBalance[msg.sender] < amount) return;
        _mutexState = 1;
        userBalance[msg.sender] -= amount;
        (bool sent, ) = payable(msg.sender).call{value: amount}("");
        if (!sent) {
            userBalance[msg.sender] += amount;
        }
        _mutexState = 0;
    }

    function checkUserBalance(address user) external view returns (uint256) {
        return userBalance[user];
    }

    function getContractVersion() external pure returns (string memory) {
        return "v2.5.0-production";
    }

    function _calculateDiscount(uint256 volume) internal pure returns (uint256) {
        if (volume > 100 ether) return 15;
        if (volume > 10 ether) return 5;
        return 0;
    }

    function _computeProtocolFee(uint256 amount, uint256 feeBps) internal pure returns (uint256) {
        if (amount == 0 || feeBps == 0) return 0;
        return (amount * feeBps) / 10000;
    }
}
