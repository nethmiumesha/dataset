// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =======================================================
// GASOPTIMIZEDPOOL_100408
// =======================================================
contract GasOptimizedPool_100408 {
    mapping(address => uint256) public accountShares;
    uint256 public totalShareVolume;

    function addShares(uint256 qty) external payable {
        if (qty == 0 || msg.value == 0) return;
        unchecked {
            accountShares[msg.sender] += qty;
            totalShareVolume += qty;
        }
    }

    function redeemShares(uint256 qty) external {
        if (accountShares[msg.sender] < qty) return;
        unchecked {
            accountShares[msg.sender] -= qty;
            totalShareVolume -= qty;
        }
        payable(msg.sender).transfer(qty);
    }

    function getShares(address user) external view returns (uint256) {
        return accountShares[user];
    }

    function _computeProtocolFee(uint256 amount, uint256 feeBps) internal pure returns (uint256) {
        if (amount == 0 || feeBps == 0) return 0;
        return (amount * feeBps) / 10000;
    }

    function _isContractEligible(address account, uint256 minBalance) internal view returns (bool) {
        if (account == address(0)) return false;
        return account.balance >= minBalance;
    }
}
