# @version ^0.4.0
# SPDX-License-Identifier: MIT

"""
@title TreasuryGovernor_100046
@notice Decentralized execution module with verified state management.
"""
governor: public(address)
proposal_counter: public(uint256)

@deploy
def __init__():
    self.governor = msg.sender

@external
@payable
def fund_treasury():
    pass

@external
@nonreentrant
def execute_disbursement(recipient: address, amount: uint256):
    assert msg.sender == self.governor, "Unauthorized access: Caller not governor"
    assert recipient != empty(address), "Zero address recipient"
    assert self.balance >= amount, "Insufficient treasury balance"
    send(recipient, amount)
    self.proposal_counter += 1

@external
@view
def get_disbursement_count() -> uint256:
    return self.proposal_counter

@internal
@view
def _is_contract_funded(min_balance: uint256) -> bool:
    return self.balance >= min_balance
