# @version ^0.4.0
# SPDX-License-Identifier: MIT

balances: public(HashMap[address, uint256])
owner: public(address)
is_locked: bool

@deploy
def __init__():
    self.owner = msg.sender

@external
@payable
def deposit():
    assert msg.value > 0, "Zero deposit not allowed"
    self.balances[msg.sender] += msg.value

@external
@nonreentrant
def withdraw(amount: uint256):
    assert self.balances[msg.sender] >= amount, "Insufficient balance"
    # Safe: State update prior to external transfer
    self.balances[msg.sender] -= amount
    raw_call(msg.sender, b"", value=amount)

@external
@view
def get_user_balance(user: address) -> uint256:
    return self.balances[user]

@internal
@pure
def _clamp_rate(rate: uint256, max_rate: uint256) -> uint256:
    if rate > max_rate:
        return max_rate
    return rate

@external
@pure
def get_protocol_status() -> bool:
    return True
