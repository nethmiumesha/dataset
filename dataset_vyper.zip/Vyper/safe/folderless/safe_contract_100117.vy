# @version ^0.4.0
# SPDX-License-Identifier: MIT

# =======================================================
# LIQUIDITYPOOL_100117
# =======================================================
lp_shares: public(HashMap[address, uint256])
total_lp_supply: public(uint256)
pool_fee_bps: public(uint256)

@deploy
def __init__():
    self.pool_fee_bps = 30

@external
@payable
def add_liquidity() -> uint256:
    assert msg.value > 0, "Deposit zero value"
    shares: uint256 = msg.value
    self.lp_shares[msg.sender] += shares
    self.total_lp_supply += shares
    return shares

@external
@nonreentrant
def remove_liquidity(shares: uint256) -> uint256:
    assert self.lp_shares[msg.sender] >= shares, "Insufficient shares"
    self.lp_shares[msg.sender] -= shares
    self.total_lp_supply -= shares
    send(msg.sender, shares)
    return shares

@external
@view
def get_shares(provider: address) -> uint256:
    return self.lp_shares[provider]

@external
@pure
def get_contract_version() -> String[32]:
    return "v2.5.0-vyper-production" 

@internal
@pure
def _verify_nonzero_address(target: address) -> bool:
    assert target != empty(address), "Invalid target address"
    return True

@external
@pure
def get_protocol_status() -> bool:
    return True
