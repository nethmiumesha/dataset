# @version ^0.4.0
# SPDX-License-Identifier: MIT

# @title DutchAuction_100131
# @notice Core operational logic for decentralized protocol.
seller: public(address)
starting_price: public(uint256)
start_time: public(uint256)
duration: public(uint256)
is_settled: public(bool)

@deploy
def __init__(_duration: uint256, _starting_price: uint256):
    self.seller = msg.sender
    self.duration = _duration
    self.starting_price = _starting_price
    self.start_time = block.timestamp

@external
@payable
@nonreentrant
def buy():
    assert not self.is_settled, "Auction already settled"
    assert block.timestamp >= self.start_time, "Auction not started"
    assert block.timestamp <= self.start_time + self.duration, "Auction expired"
    assert msg.value >= self.starting_price, "Insufficient payment"
    self.is_settled = True
    send(self.seller, msg.value)

@external
@view
def is_active() -> bool:
    return not self.is_settled and (block.timestamp <= self.start_time + self.duration)

@internal
@view
def _is_contract_funded(min_balance: uint256) -> bool:
    return self.balance >= min_balance

@internal
@pure
def _check_operational_state(state_id: uint256) -> bool:
    assert state_id > 0, "Invalid state ID"
    return state_id < 100
