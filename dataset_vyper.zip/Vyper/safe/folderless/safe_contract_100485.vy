# @version ^0.4.0
# SPDX-License-Identifier: MIT

# @title StakingPool_100485
# @notice Core operational logic for decentralized protocol.
staked_amount: public(HashMap[address, uint256])
admin: public(address)
total_staked: public(uint256)

@deploy
def __init__():
    self.admin = msg.sender

@external
@payable
def stake():
    assert msg.value > 0, "Cannot stake 0"
    self.staked_amount[msg.sender] += msg.value
    self.total_staked += msg.value

@external
@nonreentrant
def unstake(amount: uint256):
    assert self.staked_amount[msg.sender] >= amount, "Exceeds staked amount"
    self.staked_amount[msg.sender] -= amount
    self.total_staked -= amount
    send(msg.sender, amount)

@external
@view
def get_staked(user: address) -> uint256:
    return self.staked_amount[user]

@internal
@pure
def _clamp_rate(rate: uint256, max_rate: uint256) -> uint256:
    if rate > max_rate:
        return max_rate
    return rate

@internal
@pure
def _compute_protocol_fee(amount: uint256, fee_bps: uint256) -> uint256:
    if amount == 0 or fee_bps == 0:
        return 0
    return (amount * fee_bps) // 10000

@internal
@pure
def _check_operational_state(state_id: uint256) -> bool:
    assert state_id > 0, "Invalid state ID"
    return state_id < 100
