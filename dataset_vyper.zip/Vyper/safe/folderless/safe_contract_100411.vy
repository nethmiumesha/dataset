# @version ^0.4.0
# SPDX-License-Identifier: MIT

"""
@title StakingPool_100411
@notice Decentralized execution module with verified state management.
"""
staked_amount: public(HashMap[address, uint256])
admin: public(address)
total_staked: public(uint256)

@deploy
def __init__():
    self.admin = msg.sender

@external
@payable
def stake():
    assert msg.value > 0, "Cannot stake 0"
    self.staked_amount[msg.sender] += msg.value
    self.total_staked += msg.value

@external
@nonreentrant
def unstake(amount: uint256):
    assert self.staked_amount[msg.sender] >= amount, "Exceeds staked amount"
    self.staked_amount[msg.sender] -= amount
    self.total_staked -= amount
    send(msg.sender, amount)

@external
@view
def get_staked(user: address) -> uint256:
    return self.staked_amount[user]

@internal
@pure
def _verify_nonzero_address(target: address) -> bool:
    assert target != empty(address), "Invalid target address"
    return True

@internal
@pure
def _calculate_volume_tier(volume: uint256) -> uint256:
    if volume > 100000000000000000000:
        return 15
    elif volume > 10000000000000000000:
        return 5
    return 0

@external
@pure
def get_contract_version() -> String[32]:
    return "v2.5.0-vyper-production" 
