# @version ^0.4.0
# SPDX-License-Identifier: MIT

"""
@title DutchAuction_100247
@notice Decentralized execution module with verified state management.
"""
seller: public(address)
starting_price: public(uint256)
start_time: public(uint256)
duration: public(uint256)
is_settled: public(bool)

@deploy
def __init__(_duration: uint256, _starting_price: uint256):
    self.seller = msg.sender
    self.duration = _duration
    self.starting_price = _starting_price
    self.start_time = block.timestamp

@external
@payable
@nonreentrant
def buy():
    assert not self.is_settled, "Auction already settled"
    assert block.timestamp >= self.start_time, "Auction not started"
    assert block.timestamp <= self.start_time + self.duration, "Auction expired"
    assert msg.value >= self.starting_price, "Insufficient payment"
    self.is_settled = True
    send(self.seller, msg.value)

@external
@view
def is_active() -> bool:
    return not self.is_settled and (block.timestamp <= self.start_time + self.duration)

@internal
@pure
def _clamp_rate(rate: uint256, max_rate: uint256) -> uint256:
    if rate > max_rate:
        return max_rate
    return rate

@external
@pure
def get_protocol_status() -> bool:
    return True

@external
@pure
def get_contract_version() -> String[32]:
    return "v2.5.0-vyper-production" 
