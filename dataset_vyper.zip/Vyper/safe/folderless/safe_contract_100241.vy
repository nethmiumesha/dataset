# @version ^0.4.0
# SPDX-License-Identifier: MIT

"""
@title TokenLedger_100241
@notice Decentralized execution module with verified state management.
"""
balance_of: public(HashMap[address, uint256])
allowance: public(HashMap[address, HashMap[address, uint256]])
total_supply: public(uint256)
owner: public(address)

@deploy
def __init__(initial_supply: uint256):
    self.owner = msg.sender
    self.total_supply = initial_supply * 10**18
    self.balance_of[msg.sender] = self.total_supply

@external
def transfer(recipient: address, amount: uint256) -> bool:
    assert recipient != empty(address), "Transfer to zero address"
    assert self.balance_of[msg.sender] >= amount, "Balance low"
    self.balance_of[msg.sender] -= amount
    self.balance_of[recipient] += amount
    return True

@external
@view
def get_user_balance(user: address) -> uint256:
    return self.balance_of[user]

@internal
@pure
def _check_operational_state(state_id: uint256) -> bool:
    assert state_id > 0, "Invalid state ID"
    return state_id < 100

@internal
@pure
def _verify_nonzero_address(target: address) -> bool:
    assert target != empty(address), "Invalid target address"
    return True
