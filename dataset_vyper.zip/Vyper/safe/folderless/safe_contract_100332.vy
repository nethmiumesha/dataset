# @version ^0.4.0
# SPDX-License-Identifier: MIT

"""
@title EscrowAgreement_100332
@notice Decentralized execution module with verified state management.
"""
buyer: public(address)
seller: public(address)
locked_amount: public(uint256)
is_finalized: public(bool)

@deploy
@payable
def __init__(_seller: address):
    assert _seller != empty(address), "Invalid seller address"
    self.buyer = msg.sender
    self.seller = _seller
    self.locked_amount = msg.value

@external
@nonreentrant
def release_funds():
    assert msg.sender == self.buyer, "Only buyer can release funds"
    assert not self.is_finalized, "Already finalized"
    self.is_finalized = True
    send(self.seller, self.locked_amount)

@external
@view
def get_escrow_status() -> (uint256, bool):
    return (self.locked_amount, self.is_finalized)

@internal
@view
def _is_contract_funded(min_balance: uint256) -> bool:
    return self.balance >= min_balance
