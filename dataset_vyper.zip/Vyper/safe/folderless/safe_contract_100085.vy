# @version ^0.4.0
# SPDX-License-Identifier: MIT

governor: public(address)
proposal_counter: public(uint256)

@deploy
def __init__():
    self.governor = msg.sender

@external
@payable
def fund_treasury():
    pass

@external
@nonreentrant
def execute_disbursement(recipient: address, amount: uint256):
    assert msg.sender == self.governor, "Unauthorized access: Caller not governor"
    assert recipient != empty(address), "Zero address recipient"
    assert self.balance >= amount, "Insufficient treasury balance"
    send(recipient, amount)
    self.proposal_counter += 1

@external
@view
def get_disbursement_count() -> uint256:
    return self.proposal_counter

@internal
@view
def _is_contract_funded(min_balance: uint256) -> bool:
    return self.balance >= min_balance

@internal
@pure
def _check_operational_state(state_id: uint256) -> bool:
    assert state_id > 0, "Invalid state ID"
    return state_id < 100

@internal
@pure
def _clamp_rate(rate: uint256, max_rate: uint256) -> uint256:
    if rate > max_rate:
        return max_rate
    return rate
