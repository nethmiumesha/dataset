# @version ^0.4.0
# SPDX-License-Identifier: MIT

# =======================================================
# STAKINGPOOL_100052
# =======================================================
staked_amount: public(HashMap[address, uint256])
admin: public(address)
total_staked: public(uint256)

@deploy
def __init__():
    self.admin = msg.sender

@external
@payable
def stake():
    assert msg.value > 0, "Cannot stake 0"
    self.staked_amount[msg.sender] += msg.value
    self.total_staked += msg.value

@external
@nonreentrant
def unstake(amount: uint256):
    assert self.staked_amount[msg.sender] >= amount, "Exceeds staked amount"
    self.staked_amount[msg.sender] -= amount
    self.total_staked -= amount
    send(msg.sender, amount)

@external
@view
def get_staked(user: address) -> uint256:
    return self.staked_amount[user]

@internal
@pure
def _compute_protocol_fee(amount: uint256, fee_bps: uint256) -> uint256:
    if amount == 0 or fee_bps == 0:
        return 0
    return (amount * fee_bps) // 10000
