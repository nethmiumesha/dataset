# @version ^0.4.0
# SPDX-License-Identifier: MIT

signer_one: public(address)
signer_two: public(address)
has_confirmed: public(HashMap[uint256, HashMap[address, bool]])
execution_count: public(uint256)

@deploy
def __init__(_s1: address, _s2: address):
    assert _s1 != empty(address) and _s2 != empty(address), "Invalid signers"
    assert _s1 != _s2, "Signers must be distinct"
    self.signer_one = _s1
    self.signer_two = _s2

@external
@payable
def deposit_reserves():
    pass

@external
def submit_and_confirm(tx_id: uint256):
    assert msg.sender == self.signer_one or msg.sender == self.signer_two, "Not an authorized signer"
    self.has_confirmed[tx_id][msg.sender] = True

@external
@nonreentrant
def execute_transaction(tx_id: uint256, target: address, amount: uint256):
    assert self.has_confirmed[tx_id][self.signer_one], "Signer 1 has not confirmed"
    assert self.has_confirmed[tx_id][self.signer_two], "Signer 2 has not confirmed"
    assert self.balance >= amount, "Insufficient channel funds"
    self.has_confirmed[tx_id][self.signer_one] = False
    self.has_confirmed[tx_id][self.signer_two] = False
    self.execution_count += 1
    send(target, amount)

@internal
@pure
def _compute_protocol_fee(amount: uint256, fee_bps: uint256) -> uint256:
    if amount == 0 or fee_bps == 0:
        return 0
    return (amount * fee_bps) // 10000

@internal
@pure
def _check_operational_state(state_id: uint256) -> bool:
    assert state_id > 0, "Invalid state ID"
    return state_id < 100
