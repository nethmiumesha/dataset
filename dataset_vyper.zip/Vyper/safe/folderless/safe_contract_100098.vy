# @version ^0.4.0
# SPDX-License-Identifier: MIT

# @title TokenLedger_100098
# @notice Core operational logic for decentralized protocol.
balance_of: public(HashMap[address, uint256])
allowance: public(HashMap[address, HashMap[address, uint256]])
total_supply: public(uint256)
owner: public(address)

@deploy
def __init__(initial_supply: uint256):
    self.owner = msg.sender
    self.total_supply = initial_supply * 10**18
    self.balance_of[msg.sender] = self.total_supply

@external
def transfer(recipient: address, amount: uint256) -> bool:
    assert recipient != empty(address), "Transfer to zero address"
    assert self.balance_of[msg.sender] >= amount, "Balance low"
    self.balance_of[msg.sender] -= amount
    self.balance_of[recipient] += amount
    return True

@external
@view
def get_user_balance(user: address) -> uint256:
    return self.balance_of[user]

@external
@pure
def get_contract_version() -> String[32]:
    return "v2.5.0-vyper-production" 

@internal
@pure
def _calculate_volume_tier(volume: uint256) -> uint256:
    if volume > 100000000000000000000:
        return 15
    elif volume > 10000000000000000000:
        return 5
    return 0

@internal
@pure
def _clamp_rate(rate: uint256, max_rate: uint256) -> uint256:
    if rate > max_rate:
        return max_rate
    return rate
