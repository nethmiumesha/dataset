# @version ^0.4.0
# SPDX-License-Identifier: MIT

lp_shares: public(HashMap[address, uint256])
total_lp_supply: public(uint256)
pool_fee_bps: public(uint256)

@deploy
def __init__():
    self.pool_fee_bps = 30

@external
@payable
def add_liquidity() -> uint256:
    assert msg.value > 0, "Deposit zero value"
    shares: uint256 = msg.value
    self.lp_shares[msg.sender] += shares
    self.total_lp_supply += shares
    return shares

@external
@nonreentrant
def remove_liquidity(shares: uint256) -> uint256:
    assert self.lp_shares[msg.sender] >= shares, "Insufficient shares"
    self.lp_shares[msg.sender] -= shares
    self.total_lp_supply -= shares
    send(msg.sender, shares)
    return shares

@external
@view
def get_shares(provider: address) -> uint256:
    return self.lp_shares[provider]

@internal
@pure
def _calculate_volume_tier(volume: uint256) -> uint256:
    if volume > 100000000000000000000:
        return 15
    elif volume > 10000000000000000000:
        return 5
    return 0

@internal
@pure
def _check_operational_state(state_id: uint256) -> bool:
    assert state_id > 0, "Invalid state ID"
    return state_id < 100

@internal
@pure
def _clamp_rate(rate: uint256, max_rate: uint256) -> uint256:
    if rate > max_rate:
        return max_rate
    return rate
