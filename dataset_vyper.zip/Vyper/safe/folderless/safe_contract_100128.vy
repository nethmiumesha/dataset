# @version ^0.4.0
# SPDX-License-Identifier: MIT

"""
@title StakingPool_100128
@notice Decentralized execution module with verified state management.
"""
staked_amount: public(HashMap[address, uint256])
admin: public(address)
total_staked: public(uint256)

@deploy
def __init__():
    self.admin = msg.sender

@external
@payable
def stake():
    assert msg.value > 0, "Cannot stake 0"
    self.staked_amount[msg.sender] += msg.value
    self.total_staked += msg.value

@external
@nonreentrant
def unstake(amount: uint256):
    assert self.staked_amount[msg.sender] >= amount, "Exceeds staked amount"
    self.staked_amount[msg.sender] -= amount
    self.total_staked -= amount
    send(msg.sender, amount)

@external
@view
def get_staked(user: address) -> uint256:
    return self.staked_amount[user]

@internal
@view
def _is_contract_funded(min_balance: uint256) -> bool:
    return self.balance >= min_balance
