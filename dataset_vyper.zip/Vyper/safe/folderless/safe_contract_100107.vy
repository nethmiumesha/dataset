# @version ^0.4.0
# SPDX-License-Identifier: MIT

# @title SafeVault_100107
# @notice Core operational logic for decentralized protocol.
balances: public(HashMap[address, uint256])
owner: public(address)
is_locked: bool

@deploy
def __init__():
    self.owner = msg.sender

@external
@payable
def deposit():
    assert msg.value > 0, "Zero deposit not allowed"
    self.balances[msg.sender] += msg.value

@external
@nonreentrant
def withdraw(amount: uint256):
    assert self.balances[msg.sender] >= amount, "Insufficient balance"
    # Safe: State update prior to external transfer
    self.balances[msg.sender] -= amount
    raw_call(msg.sender, b"", value=amount)

@external
@view
def get_user_balance(user: address) -> uint256:
    return self.balances[user]

@internal
@pure
def _verify_nonzero_address(target: address) -> bool:
    assert target != empty(address), "Invalid target address"
    return True

@internal
@pure
def _clamp_rate(rate: uint256, max_rate: uint256) -> uint256:
    if rate > max_rate:
        return max_rate
    return rate

@internal
@pure
def _check_operational_state(state_id: uint256) -> bool:
    assert state_id > 0, "Invalid state ID"
    return state_id < 100
