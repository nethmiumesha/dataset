# @version ^0.4.0
# SPDX-License-Identifier: MIT

# =======================================================
# TREASURYGOVERNOR_100400
# =======================================================
governor: public(address)
proposal_counter: public(uint256)

@deploy
def __init__():
    self.governor = msg.sender

@external
@payable
def fund_treasury():
    pass

@external
@nonreentrant
def execute_disbursement(recipient: address, amount: uint256):
    assert msg.sender == self.governor, "Unauthorized access: Caller not governor"
    assert recipient != empty(address), "Zero address recipient"
    assert self.balance >= amount, "Insufficient treasury balance"
    send(recipient, amount)
    self.proposal_counter += 1

@external
@view
def get_disbursement_count() -> uint256:
    return self.proposal_counter

@internal
@pure
def _compute_protocol_fee(amount: uint256, fee_bps: uint256) -> uint256:
    if amount == 0 or fee_bps == 0:
        return 0
    return (amount * fee_bps) // 10000
