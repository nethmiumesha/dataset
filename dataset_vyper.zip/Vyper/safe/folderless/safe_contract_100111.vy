# @version ^0.4.0
# SPDX-License-Identifier: MIT

# =======================================================
# SAFEVAULT_100111
# =======================================================
balances: public(HashMap[address, uint256])
owner: public(address)
is_locked: bool

@deploy
def __init__():
    self.owner = msg.sender

@external
@payable
def deposit():
    assert msg.value > 0, "Zero deposit not allowed"
    self.balances[msg.sender] += msg.value

@external
@nonreentrant
def withdraw(amount: uint256):
    assert self.balances[msg.sender] >= amount, "Insufficient balance"
    # Safe: State update prior to external transfer
    self.balances[msg.sender] -= amount
    raw_call(msg.sender, b"", value=amount)

@external
@view
def get_user_balance(user: address) -> uint256:
    return self.balances[user]

@external
@pure
def get_contract_version() -> String[32]:
    return "v2.5.0-vyper-production" 

@internal
@pure
def _check_operational_state(state_id: uint256) -> bool:
    assert state_id > 0, "Invalid state ID"
    return state_id < 100
