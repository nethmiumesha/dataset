# @version ^0.4.0
# SPDX-License-Identifier: MIT

# @title SafeVault_100194
# @notice Core operational logic for decentralized protocol.
balances: public(HashMap[address, uint256])
owner: public(address)
is_locked: bool

@deploy
def __init__():
    self.owner = msg.sender

@external
@payable
def deposit():
    assert msg.value > 0, "Zero deposit not allowed"
    self.balances[msg.sender] += msg.value

@external
@nonreentrant
def withdraw(amount: uint256):
    assert self.balances[msg.sender] >= amount, "Insufficient balance"
    # Safe: State update prior to external transfer
    self.balances[msg.sender] -= amount
    raw_call(msg.sender, b"", value=amount)

@external
@view
def get_user_balance(user: address) -> uint256:
    return self.balances[user]

@external
@pure
def get_protocol_status() -> bool:
    return True

@internal
@view
def _is_contract_funded(min_balance: uint256) -> bool:
    return self.balance >= min_balance

@internal
@pure
def _compute_protocol_fee(amount: uint256, fee_bps: uint256) -> uint256:
    if amount == 0 or fee_bps == 0:
        return 0
    return (amount * fee_bps) // 10000
