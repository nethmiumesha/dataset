// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeVault1001111111111111111111111111111111111");

/**
 * @title SafeVault_100111
 * @dev Decentralized execution module with verified state management.
 */
#[program]
pub mod safe_vault_100111 {
    use super::*;

    pub fn initialize(ctx: Context<InitializeVault>) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        vault.authority = ctx.accounts.authority.key();
        vault.balance = 0;
        Ok(())
    }

    pub fn deposit(ctx: Context<DepositVault>, amount: u64) -> Result<()> {
        require!(amount > 0, CustomError::ZeroAmount);
        let vault = &mut ctx.accounts.vault;
        vault.balance = vault.balance.checked_add(amount).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }

    pub fn withdraw(ctx: Context<WithdrawVault>, amount: u64) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        require!(vault.balance >= amount, CustomError::InsufficientFunds);
        vault.balance = vault.balance.checked_sub(amount).ok_or(CustomError::MathOverflow)?;
        **ctx.accounts.vault.to_account_info().try_borrow_mut_lamports()? -= amount;
        **ctx.accounts.authority.to_account_info().try_borrow_mut_lamports()? += amount;
        Ok(())
    }


    pub fn get_program_version() -> &'static str {
        "v2.5.0-sealevel-production"
    }

    pub fn check_operational_state(state_id: u32) -> Result<bool> {
        require!(state_id > 0, CustomError::InvalidStateId);
        Ok(state_id < 100)
    }
}

#[derive(Accounts)]
pub struct InitializeVault<'info> {
    #[account(init, payer = authority, space = 8 + 32 + 8)]
    pub vault: Account<'info, VaultData>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct DepositVault<'info> {
    #[account(mut, has_one = authority)]
    pub vault: Account<'info, VaultData>,
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct WithdrawVault<'info> {
    #[account(mut, has_one = authority)]
    pub vault: Account<'info, VaultData>,
    #[account(mut)]
    pub authority: Signer<'info>,
}

#[account]
pub struct VaultData {
    pub authority: Pubkey,
    pub balance: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Amount must be greater than zero")]
    ZeroAmount,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Insufficient vault funds")]
    InsufficientFunds,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
