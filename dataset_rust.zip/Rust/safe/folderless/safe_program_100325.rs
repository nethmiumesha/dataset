// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeMsg10032511111111111111111111111111111111");

// =======================================================
// MULTISIGEXECUTOR_100325
// =======================================================
#[program]
pub mod multisig_100325 {
    use super::*;

    pub fn confirm_and_execute(ctx: Context<MultiSigContext>, amount: u64) -> Result<()> {
        let ms = &mut ctx.accounts.multisig;
        require!(ctx.accounts.signer_a.key() == ms.signer_one, CustomError::Unauthorized);
        require!(ctx.accounts.signer_b.key() == ms.signer_two, CustomError::Unauthorized);
        ms.execution_count = ms.execution_count.checked_add(1).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }


    pub fn compute_protocol_fee(amount: u64, fee_bps: u64) -> Result<u64> {
        if amount == 0 || fee_bps == 0 {
            return Ok(0);
        }
        amount
            .checked_mul(fee_bps)
            .and_then(|v| v.checked_div(10000))
            .ok_or(error!(CustomError::MathOverflow))
    }

    pub fn get_protocol_health() -> bool {
        true
    }
}

#[derive(Accounts)]
pub struct MultiSigContext<'info> {
    #[account(mut)]
    pub multisig: Account<'info, MultiSigState>,
    pub signer_a: Signer<'info>,
    pub signer_b: Signer<'info>,
}

#[account]
pub struct MultiSigState {
    pub signer_one: Pubkey,
    pub signer_two: Pubkey,
    pub execution_count: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Unauthorized signer access")]
    Unauthorized,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
