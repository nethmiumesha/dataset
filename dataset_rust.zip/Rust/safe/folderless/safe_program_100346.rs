// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeLiq10034611111111111111111111111111111111");

#[program]
pub mod liquidity_pool_100346 {
    use super::*;

    pub fn add_liquidity(ctx: Context<AddLiquidityContext>, amount: u64) -> Result<()> {
        require!(amount > 0, CustomError::ZeroAmount);
        let pool = &mut ctx.accounts.pool;
        pool.total_lp = pool.total_lp.checked_add(amount).ok_or(CustomError::MathOverflow)?;
        let provider = &mut ctx.accounts.provider_shares;
        provider.shares = provider.shares.checked_add(amount).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }


    pub fn calculate_volume_tier(volume: u64) -> u8 {
        if volume > 100_000_000_000 {
            15
        } else if volume > 10_000_000_000 {
            5
        } else {
            0
        }
    }
}

#[derive(Accounts)]
pub struct AddLiquidityContext<'info> {
    #[account(mut)]
    pub pool: Account<'info, PoolState>,
    #[account(mut, has_one = owner)]
    pub provider_shares: Account<'info, ShareAccount>,
    pub owner: Signer<'info>,
}

#[account]
pub struct PoolState {
    pub total_lp: u64,
}

#[account]
pub struct ShareAccount {
    pub owner: Pubkey,
    pub shares: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Zero amount cannot be added")]
    ZeroAmount,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
