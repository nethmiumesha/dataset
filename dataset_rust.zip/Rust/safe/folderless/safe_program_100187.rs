// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeGov10018711111111111111111111111111111111");

// =======================================================
// TREASURYGOVERNOR_100187
// =======================================================
#[program]
pub mod treasury_governor_100187 {
    use super::*;

    pub fn disburse(ctx: Context<DisburseFunds>, amount: u64) -> Result<()> {
        let treasury = &mut ctx.accounts.treasury;
        require!(treasury.balance >= amount, CustomError::InsufficientFunds);
        treasury.balance = treasury.balance.checked_sub(amount).ok_or(CustomError::MathOverflow)?;
        treasury.disbursement_count = treasury.disbursement_count.checked_add(1).ok_or(CustomError::MathOverflow)?;

        **ctx.accounts.treasury.to_account_info().try_borrow_mut_lamports()? -= amount;
        **ctx.accounts.recipient.to_account_info().try_borrow_mut_lamports()? += amount;
        Ok(())
    }


    pub fn calculate_volume_tier(volume: u64) -> u8 {
        if volume > 100_000_000_000 {
            15
        } else if volume > 10_000_000_000 {
            5
        } else {
            0
        }
    }

    pub fn compute_protocol_fee(amount: u64, fee_bps: u64) -> Result<u64> {
        if amount == 0 || fee_bps == 0 {
            return Ok(0);
        }
        amount
            .checked_mul(fee_bps)
            .and_then(|v| v.checked_div(10000))
            .ok_or(error!(CustomError::MathOverflow))
    }

    pub fn get_program_version() -> &'static str {
        "v2.5.0-sealevel-production"
    }
}

#[derive(Accounts)]
pub struct DisburseFunds<'info> {
    #[account(mut, has_one = governor)]
    pub treasury: Account<'info, TreasuryState>,
    pub governor: Signer<'info>,
    /// CHECK: Recipient pubkey verified
    #[account(mut)]
    pub recipient: AccountInfo<'info>,
}

#[account]
pub struct TreasuryState {
    pub governor: Pubkey,
    pub balance: u64,
    pub disbursement_count: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Insufficient treasury balance")]
    InsufficientFunds,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
