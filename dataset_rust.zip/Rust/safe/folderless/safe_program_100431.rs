// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeGov10043111111111111111111111111111111111");

/**
 * @title TreasuryGovernor_100431
 * @dev Decentralized execution module with verified state management.
 */
#[program]
pub mod treasury_governor_100431 {
    use super::*;

    pub fn disburse(ctx: Context<DisburseFunds>, amount: u64) -> Result<()> {
        let treasury = &mut ctx.accounts.treasury;
        require!(treasury.balance >= amount, CustomError::InsufficientFunds);
        treasury.balance = treasury.balance.checked_sub(amount).ok_or(CustomError::MathOverflow)?;
        treasury.disbursement_count = treasury.disbursement_count.checked_add(1).ok_or(CustomError::MathOverflow)?;

        **ctx.accounts.treasury.to_account_info().try_borrow_mut_lamports()? -= amount;
        **ctx.accounts.recipient.to_account_info().try_borrow_mut_lamports()? += amount;
        Ok(())
    }

}

#[derive(Accounts)]
pub struct DisburseFunds<'info> {
    #[account(mut, has_one = governor)]
    pub treasury: Account<'info, TreasuryState>,
    pub governor: Signer<'info>,
    /// CHECK: Recipient pubkey verified
    #[account(mut)]
    pub recipient: AccountInfo<'info>,
}

#[account]
pub struct TreasuryState {
    pub governor: Pubkey,
    pub balance: u64,
    pub disbursement_count: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Insufficient treasury balance")]
    InsufficientFunds,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
