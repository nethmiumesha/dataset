// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeGov10025711111111111111111111111111111111");

// =======================================================
// TREASURYGOVERNOR_100257
// =======================================================
#[program]
pub mod treasury_governor_100257 {
    use super::*;

    pub fn disburse(ctx: Context<DisburseFunds>, amount: u64) -> Result<()> {
        let treasury = &mut ctx.accounts.treasury;
        require!(treasury.balance >= amount, CustomError::InsufficientFunds);
        treasury.balance = treasury.balance.checked_sub(amount).ok_or(CustomError::MathOverflow)?;
        treasury.disbursement_count = treasury.disbursement_count.checked_add(1).ok_or(CustomError::MathOverflow)?;

        **ctx.accounts.treasury.to_account_info().try_borrow_mut_lamports()? -= amount;
        **ctx.accounts.recipient.to_account_info().try_borrow_mut_lamports()? += amount;
        Ok(())
    }


    pub fn clamp_rate(rate: u64, max_rate: u64) -> u64 {
        if rate > max_rate {
            max_rate
        } else {
            rate
        }
    }

    pub fn get_protocol_health() -> bool {
        true
    }

    pub fn verify_pubkey_nonzero(target: &Pubkey) -> Result<bool> {
        require!(target != &Pubkey::default(), CustomError::InvalidPubkey);
        Ok(true)
    }
}

#[derive(Accounts)]
pub struct DisburseFunds<'info> {
    #[account(mut, has_one = governor)]
    pub treasury: Account<'info, TreasuryState>,
    pub governor: Signer<'info>,
    /// CHECK: Recipient pubkey verified
    #[account(mut)]
    pub recipient: AccountInfo<'info>,
}

#[account]
pub struct TreasuryState {
    pub governor: Pubkey,
    pub balance: u64,
    pub disbursement_count: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Insufficient treasury balance")]
    InsufficientFunds,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
