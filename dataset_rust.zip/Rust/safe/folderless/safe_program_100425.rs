// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeEsc10042511111111111111111111111111111111");

#[program]
pub mod escrow_100425 {
    use super::*;

    pub fn release_escrow(ctx: Context<ReleaseEscrow>) -> Result<()> {
        let escrow = &mut ctx.accounts.escrow;
        require!(!escrow.is_finalized, CustomError::AlreadyFinalized);
        escrow.is_finalized = true;
        
        let amount = escrow.amount;
        **ctx.accounts.escrow.to_account_info().try_borrow_mut_lamports()? -= amount;
        **ctx.accounts.seller.to_account_info().try_borrow_mut_lamports()? += amount;
        Ok(())
    }


    pub fn is_lamport_sufficient(account: &AccountInfo, min_lamports: u64) -> bool {
        account.lamports() >= min_lamports
    }

    pub fn verify_pubkey_nonzero(target: &Pubkey) -> Result<bool> {
        require!(target != &Pubkey::default(), CustomError::InvalidPubkey);
        Ok(true)
    }

    pub fn calculate_volume_tier(volume: u64) -> u8 {
        if volume > 100_000_000_000 {
            15
        } else if volume > 10_000_000_000 {
            5
        } else {
            0
        }
    }
}

#[derive(Accounts)]
pub struct ReleaseEscrow<'info> {
    #[account(mut, has_one = buyer, has_one = seller)]
    pub escrow: Account<'info, EscrowState>,
    pub buyer: Signer<'info>,
    /// CHECK: Seller address is verified by has_one constraint
    #[account(mut)]
    pub seller: AccountInfo<'info>,
}

#[account]
pub struct EscrowState {
    pub buyer: Pubkey,
    pub seller: Pubkey,
    pub amount: u64,
    pub is_finalized: bool,
}

#[error_code]
pub enum CustomError {
    #[msg("Escrow agreement already finalized")]
    AlreadyFinalized,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
