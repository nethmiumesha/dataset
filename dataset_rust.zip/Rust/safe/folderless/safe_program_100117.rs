// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeLiq10011711111111111111111111111111111111");

/**
 * @title LiquidityPool_100117
 * @dev Decentralized execution module with verified state management.
 */
#[program]
pub mod liquidity_pool_100117 {
    use super::*;

    pub fn add_liquidity(ctx: Context<AddLiquidityContext>, amount: u64) -> Result<()> {
        require!(amount > 0, CustomError::ZeroAmount);
        let pool = &mut ctx.accounts.pool;
        pool.total_lp = pool.total_lp.checked_add(amount).ok_or(CustomError::MathOverflow)?;
        let provider = &mut ctx.accounts.provider_shares;
        provider.shares = provider.shares.checked_add(amount).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }


    pub fn get_program_version() -> &'static str {
        "v2.5.0-sealevel-production"
    }

    pub fn verify_pubkey_nonzero(target: &Pubkey) -> Result<bool> {
        require!(target != &Pubkey::default(), CustomError::InvalidPubkey);
        Ok(true)
    }

    pub fn get_protocol_health() -> bool {
        true
    }
}

#[derive(Accounts)]
pub struct AddLiquidityContext<'info> {
    #[account(mut)]
    pub pool: Account<'info, PoolState>,
    #[account(mut, has_one = owner)]
    pub provider_shares: Account<'info, ShareAccount>,
    pub owner: Signer<'info>,
}

#[account]
pub struct PoolState {
    pub total_lp: u64,
}

#[account]
pub struct ShareAccount {
    pub owner: Pubkey,
    pub shares: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Zero amount cannot be added")]
    ZeroAmount,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
