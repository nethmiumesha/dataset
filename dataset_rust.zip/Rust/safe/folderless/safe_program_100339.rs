// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};

declare_id!("SafeCpi10033911111111111111111111111111111111");

/// @title SafeTransferModule_100339
/// @notice Core operational logic for decentralized Solana/Anchor program.
#[program]
pub mod safe_transfer_100339 {
    use super::*;

    pub fn transfer_tokens(ctx: Context<TransferTokensContext>, amount: u64) -> Result<()> {
        let cpi_accounts = Transfer {
            from: ctx.accounts.from.to_account_info(),
            to: ctx.accounts.to.to_account_info(),
            authority: ctx.accounts.authority.to_account_info(),
        };
        // Safe: Token program explicitly constrained to official SPL Token Program
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        token::transfer(cpi_ctx, amount)?;
        Ok(())
    }


    pub fn clamp_rate(rate: u64, max_rate: u64) -> u64 {
        if rate > max_rate {
            max_rate
        } else {
            rate
        }
    }
}

#[derive(Accounts)]
pub struct TransferTokensContext<'info> {
    #[account(mut)]
    pub from: Account<'info, TokenAccount>,
    #[account(mut)]
    pub to: Account<'info, TokenAccount>,
    pub authority: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

#[error_code]
pub enum CustomError {
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
