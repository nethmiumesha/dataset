// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeMsg10045711111111111111111111111111111111");

#[program]
pub mod multisig_100457 {
    use super::*;

    pub fn confirm_and_execute(ctx: Context<MultiSigContext>, amount: u64) -> Result<()> {
        let ms = &mut ctx.accounts.multisig;
        require!(ctx.accounts.signer_a.key() == ms.signer_one, CustomError::Unauthorized);
        require!(ctx.accounts.signer_b.key() == ms.signer_two, CustomError::Unauthorized);
        ms.execution_count = ms.execution_count.checked_add(1).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }

}

#[derive(Accounts)]
pub struct MultiSigContext<'info> {
    #[account(mut)]
    pub multisig: Account<'info, MultiSigState>,
    pub signer_a: Signer<'info>,
    pub signer_b: Signer<'info>,
}

#[account]
pub struct MultiSigState {
    pub signer_one: Pubkey,
    pub signer_two: Pubkey,
    pub execution_count: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Unauthorized signer access")]
    Unauthorized,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
