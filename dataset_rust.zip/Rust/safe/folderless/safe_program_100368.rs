// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeGov10036811111111111111111111111111111111");

/// @title TreasuryGovernor_100368
/// @notice Core operational logic for decentralized Solana/Anchor program.
#[program]
pub mod treasury_governor_100368 {
    use super::*;

    pub fn disburse(ctx: Context<DisburseFunds>, amount: u64) -> Result<()> {
        let treasury = &mut ctx.accounts.treasury;
        require!(treasury.balance >= amount, CustomError::InsufficientFunds);
        treasury.balance = treasury.balance.checked_sub(amount).ok_or(CustomError::MathOverflow)?;
        treasury.disbursement_count = treasury.disbursement_count.checked_add(1).ok_or(CustomError::MathOverflow)?;

        **ctx.accounts.treasury.to_account_info().try_borrow_mut_lamports()? -= amount;
        **ctx.accounts.recipient.to_account_info().try_borrow_mut_lamports()? += amount;
        Ok(())
    }


    pub fn is_lamport_sufficient(account: &AccountInfo, min_lamports: u64) -> bool {
        account.lamports() >= min_lamports
    }

    pub fn get_protocol_health() -> bool {
        true
    }
}

#[derive(Accounts)]
pub struct DisburseFunds<'info> {
    #[account(mut, has_one = governor)]
    pub treasury: Account<'info, TreasuryState>,
    pub governor: Signer<'info>,
    /// CHECK: Recipient pubkey verified
    #[account(mut)]
    pub recipient: AccountInfo<'info>,
}

#[account]
pub struct TreasuryState {
    pub governor: Pubkey,
    pub balance: u64,
    pub disbursement_count: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Insufficient treasury balance")]
    InsufficientFunds,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
