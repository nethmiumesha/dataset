// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeVst10013111111111111111111111111111111111");

// =======================================================
// TIMEDVESTING_100131
// =======================================================
#[program]
pub mod timed_vesting_100131 {
    use super::*;

    pub fn claim_vested(ctx: Context<ClaimVestedContext>) -> Result<()> {
        let schedule = &mut ctx.accounts.vesting_schedule;
        let clock = Clock::get()?;
        require!(clock.unix_timestamp >= schedule.cliff_timestamp, CustomError::CliffNotReached);
        require!(!schedule.is_claimed, CustomError::AlreadyFinalized);
        schedule.is_claimed = true;

        let amount = schedule.amount;
        **ctx.accounts.vesting_schedule.to_account_info().try_borrow_mut_lamports()? -= amount;
        **ctx.accounts.beneficiary.to_account_info().try_borrow_mut_lamports()? += amount;
        Ok(())
    }


    pub fn clamp_rate(rate: u64, max_rate: u64) -> u64 {
        if rate > max_rate {
            max_rate
        } else {
            rate
        }
    }

    pub fn check_operational_state(state_id: u32) -> Result<bool> {
        require!(state_id > 0, CustomError::InvalidStateId);
        Ok(state_id < 100)
    }
}

#[derive(Accounts)]
pub struct ClaimVestedContext<'info> {
    #[account(mut, has_one = beneficiary)]
    pub vesting_schedule: Account<'info, VestingSchedule>,
    #[account(mut)]
    pub beneficiary: Signer<'info>,
}

#[account]
pub struct VestingSchedule {
    pub beneficiary: Pubkey,
    pub cliff_timestamp: i64,
    pub amount: u64,
    pub is_claimed: bool,
}

#[error_code]
pub enum CustomError {
    #[msg("Vesting cliff deadline has not been reached yet")]
    CliffNotReached,
    #[msg("Vested tokens already claimed")]
    AlreadyFinalized,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
