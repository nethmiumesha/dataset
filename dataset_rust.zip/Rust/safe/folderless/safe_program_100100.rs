// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeStk10010011111111111111111111111111111111");

/**
 * @title StakingPool_100100
 * @dev Decentralized execution module with verified state management.
 */
#[program]
pub mod staking_pool_100100 {
    use super::*;

    pub fn stake(ctx: Context<StakeContext>, amount: u64) -> Result<()> {
        require!(amount > 0, CustomError::ZeroAmount);
        let user_stake = &mut ctx.accounts.user_stake;
        user_stake.staked_amount = user_stake.staked_amount.checked_add(amount).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }

    pub fn unstake(ctx: Context<UnstakeContext>, amount: u64) -> Result<()> {
        let user_stake = &mut ctx.accounts.user_stake;
        require!(user_stake.staked_amount >= amount, CustomError::InsufficientFunds);
        user_stake.staked_amount = user_stake.staked_amount.checked_sub(amount).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }


    pub fn calculate_volume_tier(volume: u64) -> u8 {
        if volume > 100_000_000_000 {
            15
        } else if volume > 10_000_000_000 {
            5
        } else {
            0
        }
    }
}

#[derive(Accounts)]
pub struct StakeContext<'info> {
    #[account(mut, has_one = owner)]
    pub user_stake: Account<'info, StakeAccount>,
    pub owner: Signer<'info>,
}

#[derive(Accounts)]
pub struct UnstakeContext<'info> {
    #[account(mut, has_one = owner)]
    pub user_stake: Account<'info, StakeAccount>,
    pub owner: Signer<'info>,
}

#[account]
pub struct StakeAccount {
    pub owner: Pubkey,
    pub staked_amount: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Zero amount requested")]
    ZeroAmount,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Insufficient staked balance")]
    InsufficientFunds,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
