// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeEsc10013811111111111111111111111111111111");

// =======================================================
// ESCROWAGREEMENT_100138
// =======================================================
#[program]
pub mod escrow_100138 {
    use super::*;

    pub fn release_escrow(ctx: Context<ReleaseEscrow>) -> Result<()> {
        let escrow = &mut ctx.accounts.escrow;
        require!(!escrow.is_finalized, CustomError::AlreadyFinalized);
        escrow.is_finalized = true;
        
        let amount = escrow.amount;
        **ctx.accounts.escrow.to_account_info().try_borrow_mut_lamports()? -= amount;
        **ctx.accounts.seller.to_account_info().try_borrow_mut_lamports()? += amount;
        Ok(())
    }


    pub fn compute_protocol_fee(amount: u64, fee_bps: u64) -> Result<u64> {
        if amount == 0 || fee_bps == 0 {
            return Ok(0);
        }
        amount
            .checked_mul(fee_bps)
            .and_then(|v| v.checked_div(10000))
            .ok_or(error!(CustomError::MathOverflow))
    }

    pub fn clamp_rate(rate: u64, max_rate: u64) -> u64 {
        if rate > max_rate {
            max_rate
        } else {
            rate
        }
    }

    pub fn verify_pubkey_nonzero(target: &Pubkey) -> Result<bool> {
        require!(target != &Pubkey::default(), CustomError::InvalidPubkey);
        Ok(true)
    }
}

#[derive(Accounts)]
pub struct ReleaseEscrow<'info> {
    #[account(mut, has_one = buyer, has_one = seller)]
    pub escrow: Account<'info, EscrowState>,
    pub buyer: Signer<'info>,
    /// CHECK: Seller address is verified by has_one constraint
    #[account(mut)]
    pub seller: AccountInfo<'info>,
}

#[account]
pub struct EscrowState {
    pub buyer: Pubkey,
    pub seller: Pubkey,
    pub amount: u64,
    pub is_finalized: bool,
}

#[error_code]
pub enum CustomError {
    #[msg("Escrow agreement already finalized")]
    AlreadyFinalized,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
