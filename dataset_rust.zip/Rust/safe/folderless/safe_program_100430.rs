// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeVst10043011111111111111111111111111111111");

#[program]
pub mod timed_vesting_100430 {
    use super::*;

    pub fn claim_vested(ctx: Context<ClaimVestedContext>) -> Result<()> {
        let schedule = &mut ctx.accounts.vesting_schedule;
        let clock = Clock::get()?;
        require!(clock.unix_timestamp >= schedule.cliff_timestamp, CustomError::CliffNotReached);
        require!(!schedule.is_claimed, CustomError::AlreadyFinalized);
        schedule.is_claimed = true;

        let amount = schedule.amount;
        **ctx.accounts.vesting_schedule.to_account_info().try_borrow_mut_lamports()? -= amount;
        **ctx.accounts.beneficiary.to_account_info().try_borrow_mut_lamports()? += amount;
        Ok(())
    }


    pub fn compute_protocol_fee(amount: u64, fee_bps: u64) -> Result<u64> {
        if amount == 0 || fee_bps == 0 {
            return Ok(0);
        }
        amount
            .checked_mul(fee_bps)
            .and_then(|v| v.checked_div(10000))
            .ok_or(error!(CustomError::MathOverflow))
    }

    pub fn get_protocol_health() -> bool {
        true
    }
}

#[derive(Accounts)]
pub struct ClaimVestedContext<'info> {
    #[account(mut, has_one = beneficiary)]
    pub vesting_schedule: Account<'info, VestingSchedule>,
    #[account(mut)]
    pub beneficiary: Signer<'info>,
}

#[account]
pub struct VestingSchedule {
    pub beneficiary: Pubkey,
    pub cliff_timestamp: i64,
    pub amount: u64,
    pub is_claimed: bool,
}

#[error_code]
pub enum CustomError {
    #[msg("Vesting cliff deadline has not been reached yet")]
    CliffNotReached,
    #[msg("Vested tokens already claimed")]
    AlreadyFinalized,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
