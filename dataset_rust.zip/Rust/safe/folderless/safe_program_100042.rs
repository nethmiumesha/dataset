// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeStk10004211111111111111111111111111111111");

// =======================================================
// STAKINGPOOL_100042
// =======================================================
#[program]
pub mod staking_pool_100042 {
    use super::*;

    pub fn stake(ctx: Context<StakeContext>, amount: u64) -> Result<()> {
        require!(amount > 0, CustomError::ZeroAmount);
        let user_stake = &mut ctx.accounts.user_stake;
        user_stake.staked_amount = user_stake.staked_amount.checked_add(amount).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }

    pub fn unstake(ctx: Context<UnstakeContext>, amount: u64) -> Result<()> {
        let user_stake = &mut ctx.accounts.user_stake;
        require!(user_stake.staked_amount >= amount, CustomError::InsufficientFunds);
        user_stake.staked_amount = user_stake.staked_amount.checked_sub(amount).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }


    pub fn get_program_version() -> &'static str {
        "v2.5.0-sealevel-production"
    }
}

#[derive(Accounts)]
pub struct StakeContext<'info> {
    #[account(mut, has_one = owner)]
    pub user_stake: Account<'info, StakeAccount>,
    pub owner: Signer<'info>,
}

#[derive(Accounts)]
pub struct UnstakeContext<'info> {
    #[account(mut, has_one = owner)]
    pub user_stake: Account<'info, StakeAccount>,
    pub owner: Signer<'info>,
}

#[account]
pub struct StakeAccount {
    pub owner: Pubkey,
    pub staked_amount: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Zero amount requested")]
    ZeroAmount,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Insufficient staked balance")]
    InsufficientFunds,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
