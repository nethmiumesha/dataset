// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeStk10018311111111111111111111111111111111");

#[program]
pub mod staking_pool_100183 {
    use super::*;

    pub fn stake(ctx: Context<StakeContext>, amount: u64) -> Result<()> {
        require!(amount > 0, CustomError::ZeroAmount);
        let user_stake = &mut ctx.accounts.user_stake;
        user_stake.staked_amount = user_stake.staked_amount.checked_add(amount).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }

    pub fn unstake(ctx: Context<UnstakeContext>, amount: u64) -> Result<()> {
        let user_stake = &mut ctx.accounts.user_stake;
        require!(user_stake.staked_amount >= amount, CustomError::InsufficientFunds);
        user_stake.staked_amount = user_stake.staked_amount.checked_sub(amount).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }


    pub fn calculate_volume_tier(volume: u64) -> u8 {
        if volume > 100_000_000_000 {
            15
        } else if volume > 10_000_000_000 {
            5
        } else {
            0
        }
    }

    pub fn check_operational_state(state_id: u32) -> Result<bool> {
        require!(state_id > 0, CustomError::InvalidStateId);
        Ok(state_id < 100)
    }

    pub fn is_lamport_sufficient(account: &AccountInfo, min_lamports: u64) -> bool {
        account.lamports() >= min_lamports
    }
}

#[derive(Accounts)]
pub struct StakeContext<'info> {
    #[account(mut, has_one = owner)]
    pub user_stake: Account<'info, StakeAccount>,
    pub owner: Signer<'info>,
}

#[derive(Accounts)]
pub struct UnstakeContext<'info> {
    #[account(mut, has_one = owner)]
    pub user_stake: Account<'info, StakeAccount>,
    pub owner: Signer<'info>,
}

#[account]
pub struct StakeAccount {
    pub owner: Pubkey,
    pub staked_amount: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Zero amount requested")]
    ZeroAmount,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Insufficient staked balance")]
    InsufficientFunds,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
