// SPDX-License-Identifier: MIT
use anchor_lang::prelude::*;

declare_id!("SafeVault1000261111111111111111111111111111111");

// =======================================================
// SAFEVAULT_100026
// =======================================================
#[program]
pub mod safe_vault_100026 {
    use super::*;

    pub fn initialize(ctx: Context<InitializeVault>) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        vault.authority = ctx.accounts.authority.key();
        vault.balance = 0;
        Ok(())
    }

    pub fn deposit(ctx: Context<DepositVault>, amount: u64) -> Result<()> {
        require!(amount > 0, CustomError::ZeroAmount);
        let vault = &mut ctx.accounts.vault;
        vault.balance = vault.balance.checked_add(amount).ok_or(CustomError::MathOverflow)?;
        Ok(())
    }

    pub fn withdraw(ctx: Context<WithdrawVault>, amount: u64) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        require!(vault.balance >= amount, CustomError::InsufficientFunds);
        vault.balance = vault.balance.checked_sub(amount).ok_or(CustomError::MathOverflow)?;
        **ctx.accounts.vault.to_account_info().try_borrow_mut_lamports()? -= amount;
        **ctx.accounts.authority.to_account_info().try_borrow_mut_lamports()? += amount;
        Ok(())
    }


    pub fn is_lamport_sufficient(account: &AccountInfo, min_lamports: u64) -> bool {
        account.lamports() >= min_lamports
    }

    pub fn verify_pubkey_nonzero(target: &Pubkey) -> Result<bool> {
        require!(target != &Pubkey::default(), CustomError::InvalidPubkey);
        Ok(true)
    }
}

#[derive(Accounts)]
pub struct InitializeVault<'info> {
    #[account(init, payer = authority, space = 8 + 32 + 8)]
    pub vault: Account<'info, VaultData>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct DepositVault<'info> {
    #[account(mut, has_one = authority)]
    pub vault: Account<'info, VaultData>,
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct WithdrawVault<'info> {
    #[account(mut, has_one = authority)]
    pub vault: Account<'info, VaultData>,
    #[account(mut)]
    pub authority: Signer<'info>,
}

#[account]
pub struct VaultData {
    pub authority: Pubkey,
    pub balance: u64,
}

#[error_code]
pub enum CustomError {
    #[msg("Amount must be greater than zero")]
    ZeroAmount,
    #[msg("Math calculation overflowed")]
    MathOverflow,
    #[msg("Insufficient vault funds")]
    InsufficientFunds,
    #[msg("Invalid pubkey provided")]
    InvalidPubkey,
    #[msg("Invalid state ID")]
    InvalidStateId,
}
