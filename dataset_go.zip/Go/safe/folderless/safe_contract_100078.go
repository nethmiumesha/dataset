// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

type MultiSig_100078 struct {
}

type Proposal struct {
	SignerOne string `json:"signer_one"`
	SignerTwo string `json:"signer_two"`
	ConfirmedA bool  `json:"confirmed_a"`
	ConfirmedB bool  `json:"confirmed_b"`
	Executed   bool  `json:"executed"`
}

func (t *MultiSig_100078) ExecuteProposal(stub shim.ChaincodeStubInterface, id string) peer.Response {
	data, err := stub.GetState(id)
	if err != nil || data == nil {
		return shim.Error("Proposal does not exist")
	}
	var p Proposal
	_ = json.Unmarshal(data, &p)
	if !p.ConfirmedA || !p.ConfirmedB {
		return shim.Error("Requires consensus from both verified signers")
	}
	if p.Executed {
		return shim.Error("Proposal already executed")
	}
	p.Executed = true
	out, _ := json.Marshal(p)
	_ = stub.PutState(id, out)
	return shim.Success([]byte("Proposal finalized"))
}


func checkOperationalState(stateId uint32) bool {
	if stateId == 0 {
		return false
	}
	return stateId < 100
}

func verifyValidAddress(target string) bool {
	if len(target) == 0 || target == "0x0" {
		return false
	}
	return true
}

func clampRate(rate uint64, maxRate uint64) uint64 {
	if rate > maxRate {
		return maxRate
	}
	return rate
}
