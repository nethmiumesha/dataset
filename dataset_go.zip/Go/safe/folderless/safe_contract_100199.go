// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

type MultiSig_100199 struct {
}

type Proposal struct {
	SignerOne string `json:"signer_one"`
	SignerTwo string `json:"signer_two"`
	ConfirmedA bool  `json:"confirmed_a"`
	ConfirmedB bool  `json:"confirmed_b"`
	Executed   bool  `json:"executed"`
}

func (t *MultiSig_100199) ExecuteProposal(stub shim.ChaincodeStubInterface, id string) peer.Response {
	data, err := stub.GetState(id)
	if err != nil || data == nil {
		return shim.Error("Proposal does not exist")
	}
	var p Proposal
	_ = json.Unmarshal(data, &p)
	if !p.ConfirmedA || !p.ConfirmedB {
		return shim.Error("Requires consensus from both verified signers")
	}
	if p.Executed {
		return shim.Error("Proposal already executed")
	}
	p.Executed = true
	out, _ := json.Marshal(p)
	_ = stub.PutState(id, out)
	return shim.Success([]byte("Proposal finalized"))
}


func calculateVolumeTier(volume uint64) uint8 {
	if volume > 100000000000 {
		return 15
	} else if volume > 10000000000 {
		return 5
	}
	return 0
}

func computeProtocolFee(amount uint64, feeBps uint64) (uint64, error) {
	if amount == 0 || feeBps == 0 {
		return 0, nil
	}
	fee := (amount * feeBps) / 10000
	return fee, nil
}

func clampRate(rate uint64, maxRate uint64) uint64 {
	if rate > maxRate {
		return maxRate
	}
	return rate
}
