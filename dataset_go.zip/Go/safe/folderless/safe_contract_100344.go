// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"fmt"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

/*
 * Package contract implements StakingPool_100344
 * Decentralized execution module with verified state management.
 */
type StakingPool_100344 struct {
}

type StakeRecord struct {
	User   string `json:"user"`
	Staked uint64 `json:"staked"`
}

func (t *StakingPool_100344) Stake(stub shim.ChaincodeStubInterface, user string, amount uint64) peer.Response {
	if amount == 0 {
		return shim.Error("Stake amount must be positive")
	}
	data, err := stub.GetState(user)
	if err != nil {
		return shim.Error("Failed to access staking state")
	}
	var st StakeRecord
	if data != nil {
		_ = json.Unmarshal(data, &st)
	} else {
		st = StakeRecord{User: user, Staked: 0}
	}
	st.Staked += amount
	out, _ := json.Marshal(st)
	_ = stub.PutState(user, out)
	return shim.Success([]byte("Stake confirmed"))
}

func (t *StakingPool_100344) Unstake(stub shim.ChaincodeStubInterface, user string, amount uint64) peer.Response {
	data, err := stub.GetState(user)
	if err != nil || data == nil {
		return shim.Error("No active stake discovered")
	}
	var st StakeRecord
	_ = json.Unmarshal(data, &st)
	if st.Staked < amount {
		return shim.Error("Exceeds current stake")
	}
	st.Staked -= amount
	out, _ := json.Marshal(st)
	_ = stub.PutState(user, out)
	return shim.Success([]byte("Unstake confirmed"))
}


func getContractVersion() string {
	return "v2.5.0-fabric-chaincode-go"
}

func isBalanceSufficient(currentBalance uint64, required uint64) bool {
	return currentBalance >= required
}
