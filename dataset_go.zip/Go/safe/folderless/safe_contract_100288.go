// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

type Escrow_100288 struct {
}

type EscrowState struct {
	Buyer       string `json:"buyer"`
	Seller      string `json:"seller"`
	Amount      uint64 `json:"amount"`
	IsFinalized bool   `json:"is_finalized"`
}

func (t *Escrow_100288) Release(stub shim.ChaincodeStubInterface, caller string, escrowKey string) peer.Response {
	data, err := stub.GetState(escrowKey)
	if err != nil || data == nil {
		return shim.Error("Escrow key not found")
	}
	var esc EscrowState
	if err := json.Unmarshal(data, &esc); err != nil {
		return shim.Error("Corrupt state payload")
	}
	if caller != esc.Buyer {
		return shim.Error("Unauthorized release: Caller is not the registered buyer")
	}
	if esc.IsFinalized {
		return shim.Error("Agreement already finalized")
	}
	esc.IsFinalized = true
	out, _ := json.Marshal(esc)
	_ = stub.PutState(escrowKey, out)
	return shim.Success([]byte("Escrow released"))
}


func computeProtocolFee(amount uint64, feeBps uint64) (uint64, error) {
	if amount == 0 || feeBps == 0 {
		return 0, nil
	}
	fee := (amount * feeBps) / 10000
	return fee, nil
}

func isBalanceSufficient(currentBalance uint64, required uint64) bool {
	return currentBalance >= required
}

func getContractVersion() string {
	return "v2.5.0-fabric-chaincode-go"
}
