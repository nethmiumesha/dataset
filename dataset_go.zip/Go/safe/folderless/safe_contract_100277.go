// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"fmt"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

// =======================================================
// STAKINGPOOL_100277
// Core operational logic for decentralized Go chaincode.
// =======================================================
type StakingPool_100277 struct {
}

type StakeRecord struct {
	User   string `json:"user"`
	Staked uint64 `json:"staked"`
}

func (t *StakingPool_100277) Stake(stub shim.ChaincodeStubInterface, user string, amount uint64) peer.Response {
	if amount == 0 {
		return shim.Error("Stake amount must be positive")
	}
	data, err := stub.GetState(user)
	if err != nil {
		return shim.Error("Failed to access staking state")
	}
	var st StakeRecord
	if data != nil {
		_ = json.Unmarshal(data, &st)
	} else {
		st = StakeRecord{User: user, Staked: 0}
	}
	st.Staked += amount
	out, _ := json.Marshal(st)
	_ = stub.PutState(user, out)
	return shim.Success([]byte("Stake confirmed"))
}

func (t *StakingPool_100277) Unstake(stub shim.ChaincodeStubInterface, user string, amount uint64) peer.Response {
	data, err := stub.GetState(user)
	if err != nil || data == nil {
		return shim.Error("No active stake discovered")
	}
	var st StakeRecord
	_ = json.Unmarshal(data, &st)
	if st.Staked < amount {
		return shim.Error("Exceeds current stake")
	}
	st.Staked -= amount
	out, _ := json.Marshal(st)
	_ = stub.PutState(user, out)
	return shim.Success([]byte("Unstake confirmed"))
}


func checkOperationalState(stateId uint32) bool {
	if stateId == 0 {
		return false
	}
	return stateId < 100
}

func verifyValidAddress(target string) bool {
	if len(target) == 0 || target == "0x0" {
		return false
	}
	return true
}

func calculateVolumeTier(volume uint64) uint8 {
	if volume > 100000000000 {
		return 15
	} else if volume > 10000000000 {
		return 5
	}
	return 0
}
