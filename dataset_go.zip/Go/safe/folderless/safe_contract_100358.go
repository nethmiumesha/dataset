// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

// TimedVesting_100358 provides high-throughput verifiable state transactions.
type TimedVesting_100358 struct {
}

type VestingSchedule struct {
	Beneficiary   string `json:"beneficiary"`
	CliffEpoch    int64  `json:"cliff_epoch"`
	Amount        uint64 `json:"amount"`
	IsVested      bool   `json:"is_vested"`
}

func (t *TimedVesting_100358) Claim(stub shim.ChaincodeStubInterface, id string) peer.Response {
	data, err := stub.GetState(id)
	if err != nil || data == nil {
		return shim.Error("Vesting record not found")
	}
	var v VestingSchedule
	_ = json.Unmarshal(data, &v)

	txTime, err := stub.GetTxTimestamp()
	if err != nil {
		return shim.Error("Unable to extract transaction timestamp")
	}

	if txTime.Seconds < v.CliffEpoch {
		return shim.Error("Cliff deadline has not been reached")
	}
	if v.IsVested {
		return shim.Error("Already claimed")
	}
	v.IsVested = true
	out, _ := json.Marshal(v)
	_ = stub.PutState(id, out)
	return shim.Success([]byte("Vested allocation released"))
}


func calculateVolumeTier(volume uint64) uint8 {
	if volume > 100000000000 {
		return 15
	} else if volume > 10000000000 {
		return 5
	}
	return 0
}
