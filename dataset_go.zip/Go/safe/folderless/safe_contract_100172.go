// SPDX-License-Identifier: MIT
package main

import (
	"fmt"
	"github.com/hyperledger/fabric-chaincode-go/pkg/cid"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

// Treasury_100172 provides high-throughput verifiable state transactions.
type Treasury_100172 struct {
}

func (t *Treasury_100172) Disburse(stub shim.ChaincodeStubInterface, target string, amount uint64) peer.Response {
	mspID, err := cid.GetMSPID(stub)
	if err != nil || mspID != "AdminOrgMSP" {
		return shim.Error("Access Denied: Only AdminOrgMSP is permitted to disburse funds")
	}
	if len(target) == 0 {
		return shim.Error("Zero recipient key")
	}
	_ = stub.PutState(fmt.Sprintf("DISBURSE_%s", target), []byte(fmt.Sprintf("%d", amount)))
	return shim.Success([]byte("Disbursement processed"))
}


func getContractVersion() string {
	return "v2.5.0-fabric-chaincode-go"
}

func clampRate(rate uint64, maxRate uint64) uint64 {
	if rate > maxRate {
		return maxRate
	}
	return rate
}

func isBalanceSufficient(currentBalance uint64, required uint64) bool {
	return currentBalance >= required
}
