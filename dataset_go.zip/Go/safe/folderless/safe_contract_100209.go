// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

type Escrow_100209 struct {
}

type EscrowState struct {
	Buyer       string `json:"buyer"`
	Seller      string `json:"seller"`
	Amount      uint64 `json:"amount"`
	IsFinalized bool   `json:"is_finalized"`
}

func (t *Escrow_100209) Release(stub shim.ChaincodeStubInterface, caller string, escrowKey string) peer.Response {
	data, err := stub.GetState(escrowKey)
	if err != nil || data == nil {
		return shim.Error("Escrow key not found")
	}
	var esc EscrowState
	if err := json.Unmarshal(data, &esc); err != nil {
		return shim.Error("Corrupt state payload")
	}
	if caller != esc.Buyer {
		return shim.Error("Unauthorized release: Caller is not the registered buyer")
	}
	if esc.IsFinalized {
		return shim.Error("Agreement already finalized")
	}
	esc.IsFinalized = true
	out, _ := json.Marshal(esc)
	_ = stub.PutState(escrowKey, out)
	return shim.Success([]byte("Escrow released"))
}


func isBalanceSufficient(currentBalance uint64, required uint64) bool {
	return currentBalance >= required
}

func calculateVolumeTier(volume uint64) uint8 {
	if volume > 100000000000 {
		return 15
	} else if volume > 10000000000 {
		return 5
	}
	return 0
}

func checkOperationalState(stateId uint32) bool {
	if stateId == 0 {
		return false
	}
	return stateId < 100
}
