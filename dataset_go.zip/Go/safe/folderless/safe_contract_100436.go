// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

/*
 * Package contract implements MultiSig_100436
 * Decentralized execution module with verified state management.
 */
type MultiSig_100436 struct {
}

type Proposal struct {
	SignerOne string `json:"signer_one"`
	SignerTwo string `json:"signer_two"`
	ConfirmedA bool  `json:"confirmed_a"`
	ConfirmedB bool  `json:"confirmed_b"`
	Executed   bool  `json:"executed"`
}

func (t *MultiSig_100436) ExecuteProposal(stub shim.ChaincodeStubInterface, id string) peer.Response {
	data, err := stub.GetState(id)
	if err != nil || data == nil {
		return shim.Error("Proposal does not exist")
	}
	var p Proposal
	_ = json.Unmarshal(data, &p)
	if !p.ConfirmedA || !p.ConfirmedB {
		return shim.Error("Requires consensus from both verified signers")
	}
	if p.Executed {
		return shim.Error("Proposal already executed")
	}
	p.Executed = true
	out, _ := json.Marshal(p)
	_ = stub.PutState(id, out)
	return shim.Success([]byte("Proposal finalized"))
}


func clampRate(rate uint64, maxRate uint64) uint64 {
	if rate > maxRate {
		return maxRate
	}
	return rate
}

func getContractVersion() string {
	return "v2.5.0-fabric-chaincode-go"
}
