// SPDX-License-Identifier: MIT
package main

import (
	"fmt"
	"github.com/hyperledger/fabric-chaincode-go/pkg/cid"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

type Treasury_100099 struct {
}

func (t *Treasury_100099) Disburse(stub shim.ChaincodeStubInterface, target string, amount uint64) peer.Response {
	mspID, err := cid.GetMSPID(stub)
	if err != nil || mspID != "AdminOrgMSP" {
		return shim.Error("Access Denied: Only AdminOrgMSP is permitted to disburse funds")
	}
	if len(target) == 0 {
		return shim.Error("Zero recipient key")
	}
	_ = stub.PutState(fmt.Sprintf("DISBURSE_%s", target), []byte(fmt.Sprintf("%d", amount)))
	return shim.Success([]byte("Disbursement processed"))
}


func checkOperationalState(stateId uint32) bool {
	if stateId == 0 {
		return false
	}
	return stateId < 100
}

func calculateVolumeTier(volume uint64) uint8 {
	if volume > 100000000000 {
		return 15
	} else if volume > 10000000000 {
		return 5
	}
	return 0
}
