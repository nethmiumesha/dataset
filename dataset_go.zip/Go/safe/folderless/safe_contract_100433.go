// SPDX-License-Identifier: MIT
package main

import (
	"fmt"
	"github.com/hyperledger/fabric-chaincode-go/pkg/cid"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

// =======================================================
// TREASURY_100433
// Core operational logic for decentralized Go chaincode.
// =======================================================
type Treasury_100433 struct {
}

func (t *Treasury_100433) Disburse(stub shim.ChaincodeStubInterface, target string, amount uint64) peer.Response {
	mspID, err := cid.GetMSPID(stub)
	if err != nil || mspID != "AdminOrgMSP" {
		return shim.Error("Access Denied: Only AdminOrgMSP is permitted to disburse funds")
	}
	if len(target) == 0 {
		return shim.Error("Zero recipient key")
	}
	_ = stub.PutState(fmt.Sprintf("DISBURSE_%s", target), []byte(fmt.Sprintf("%d", amount)))
	return shim.Success([]byte("Disbursement processed"))
}


func getContractVersion() string {
	return "v2.5.0-fabric-chaincode-go"
}

func clampRate(rate uint64, maxRate uint64) uint64 {
	if rate > maxRate {
		return maxRate
	}
	return rate
}

func calculateVolumeTier(volume uint64) uint8 {
	if volume > 100000000000 {
		return 15
	} else if volume > 10000000000 {
		return 5
	}
	return 0
}
