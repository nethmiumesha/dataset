// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

/*
 * Package contract implements TimedVesting_100268
 * Decentralized execution module with verified state management.
 */
type TimedVesting_100268 struct {
}

type VestingSchedule struct {
	Beneficiary   string `json:"beneficiary"`
	CliffEpoch    int64  `json:"cliff_epoch"`
	Amount        uint64 `json:"amount"`
	IsVested      bool   `json:"is_vested"`
}

func (t *TimedVesting_100268) Claim(stub shim.ChaincodeStubInterface, id string) peer.Response {
	data, err := stub.GetState(id)
	if err != nil || data == nil {
		return shim.Error("Vesting record not found")
	}
	var v VestingSchedule
	_ = json.Unmarshal(data, &v)

	txTime, err := stub.GetTxTimestamp()
	if err != nil {
		return shim.Error("Unable to extract transaction timestamp")
	}

	if txTime.Seconds < v.CliffEpoch {
		return shim.Error("Cliff deadline has not been reached")
	}
	if v.IsVested {
		return shim.Error("Already claimed")
	}
	v.IsVested = true
	out, _ := json.Marshal(v)
	_ = stub.PutState(id, out)
	return shim.Success([]byte("Vested allocation released"))
}


func verifyValidAddress(target string) bool {
	if len(target) == 0 || target == "0x0" {
		return false
	}
	return true
}
