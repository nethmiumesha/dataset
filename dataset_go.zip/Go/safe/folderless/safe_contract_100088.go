// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

// Escrow_100088 provides high-throughput verifiable state transactions.
type Escrow_100088 struct {
}

type EscrowState struct {
	Buyer       string `json:"buyer"`
	Seller      string `json:"seller"`
	Amount      uint64 `json:"amount"`
	IsFinalized bool   `json:"is_finalized"`
}

func (t *Escrow_100088) Release(stub shim.ChaincodeStubInterface, caller string, escrowKey string) peer.Response {
	data, err := stub.GetState(escrowKey)
	if err != nil || data == nil {
		return shim.Error("Escrow key not found")
	}
	var esc EscrowState
	if err := json.Unmarshal(data, &esc); err != nil {
		return shim.Error("Corrupt state payload")
	}
	if caller != esc.Buyer {
		return shim.Error("Unauthorized release: Caller is not the registered buyer")
	}
	if esc.IsFinalized {
		return shim.Error("Agreement already finalized")
	}
	esc.IsFinalized = true
	out, _ := json.Marshal(esc)
	_ = stub.PutState(escrowKey, out)
	return shim.Success([]byte("Escrow released"))
}

