// SPDX-License-Identifier: MIT
package main

import (
	"fmt"
	"github.com/hyperledger/fabric-chaincode-go/pkg/cid"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

// =======================================================
// TREASURY_100046
// Core operational logic for decentralized Go chaincode.
// =======================================================
type Treasury_100046 struct {
}

func (t *Treasury_100046) Disburse(stub shim.ChaincodeStubInterface, target string, amount uint64) peer.Response {
	mspID, err := cid.GetMSPID(stub)
	if err != nil || mspID != "AdminOrgMSP" {
		return shim.Error("Access Denied: Only AdminOrgMSP is permitted to disburse funds")
	}
	if len(target) == 0 {
		return shim.Error("Zero recipient key")
	}
	_ = stub.PutState(fmt.Sprintf("DISBURSE_%s", target), []byte(fmt.Sprintf("%d", amount)))
	return shim.Success([]byte("Disbursement processed"))
}


func clampRate(rate uint64, maxRate uint64) uint64 {
	if rate > maxRate {
		return maxRate
	}
	return rate
}
