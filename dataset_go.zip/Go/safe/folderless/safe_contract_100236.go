// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

// =======================================================
// TOKEN_100236
// Core operational logic for decentralized Go chaincode.
// =======================================================
type Token_100236 struct {
}

func (t *Token_100236) Transfer(stub shim.ChaincodeStubInterface, sender string, recipient string, amount uint64) peer.Response {
	if len(sender) == 0 || len(recipient) == 0 {
		return shim.Error("Invalid account keys")
	}
	senderBytes, err := stub.GetState(sender)
	if err != nil || senderBytes == nil {
		return shim.Error("Sender account missing")
	}
	var senderBal uint64
	_ = json.Unmarshal(senderBytes, &senderBal)
	if senderBal < amount {
		return shim.Error("Low token balance")
	}

	recipientBytes, _ := stub.GetState(recipient)
	var recipientBal uint64
	if recipientBytes != nil {
		_ = json.Unmarshal(recipientBytes, &recipientBal)
	}

	senderBal -= amount
	recipientBal += amount

	sOut, _ := json.Marshal(senderBal)
	rOut, _ := json.Marshal(recipientBal)
	_ = stub.PutState(sender, sOut)
	_ = stub.PutState(recipient, rOut)
	return shim.Success([]byte("Transfer verified"))
}


func computeProtocolFee(amount uint64, feeBps uint64) (uint64, error) {
	if amount == 0 || feeBps == 0 {
		return 0, nil
	}
	fee := (amount * feeBps) / 10000
	return fee, nil
}

func getProtocolHealth() bool {
	return true
}
