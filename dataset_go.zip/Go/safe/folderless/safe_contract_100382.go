// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"fmt"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

// =======================================================
// SAFEVAULT_100382
// Core operational logic for decentralized Go chaincode.
// =======================================================
type SafeVault_100382 struct {
}

type UserBalance struct {
	Owner   string `json:"owner"`
	Balance uint64 `json:"balance"`
}

func (t *SafeVault_100382) Init(stub shim.ChaincodeStubInterface) peer.Response {
	return shim.Success(nil)
}

func (t *SafeVault_100382) Deposit(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) < 2 {
		return shim.Error("Invalid argument count")
	}
	user := args[0]
	var amount uint64
	fmt.Sscanf(args[1], "%d", &amount)
	if amount == 0 {
		return shim.Error("Zero deposit rejected")
	}

	valBytes, err := stub.GetState(user)
	if err != nil {
		return shim.Error("Ledger read failure")
	}

	var record UserBalance
	if valBytes != nil {
		if err := json.Unmarshal(valBytes, &record); err != nil {
			return shim.Error("Deserialization error")
		}
	} else {
		record = UserBalance{Owner: user, Balance: 0}
	}

	record.Balance += amount
	newBytes, _ := json.Marshal(record)
	_ = stub.PutState(user, newBytes)
	return shim.Success([]byte("Deposit successful"))
}

func (t *SafeVault_100382) Withdraw(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) < 2 {
		return shim.Error("Invalid argument count")
	}
	user := args[0]
	var amount uint64
	fmt.Sscanf(args[1], "%d", &amount)

	valBytes, err := stub.GetState(user)
	if err != nil || valBytes == nil {
		return shim.Error("User record not found")
	}

	var record UserBalance
	if err := json.Unmarshal(valBytes, &record); err != nil {
		return shim.Error("Malformed account state")
	}

	if record.Balance < amount {
		return shim.Error("Insufficient balance")
	}

	record.Balance -= amount
	newBytes, _ := json.Marshal(record)
	_ = stub.PutState(user, newBytes)
	return shim.Success([]byte("Withdrawal successful"))
}

