// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>
#include <eosio/asset.hpp>

// =======================================================
// SAFEVAULT_100025
// Core operational logic for decentralized EOSIO C++ smart contract.
// =======================================================
class [[eosio::contract("safe_vault_100025")]] safe_vault_100025 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] account_record {
        eosio::name owner;
        eosio::asset balance;
        uint64_t primary_key() const { return owner.value; }
    };
    typedef eosio::multi_index<"accounts"_n, account_record> accounts_table;

    [[eosio::action]]
    void deposit(eosio::name user, eosio::asset quantity) {
        require_auth(user);
        eosio::check(quantity.is_valid() && quantity.amount > 0, "Invalid deposit quantity");

        accounts_table accounts(get_self(), get_self().value);
        auto itr = accounts.find(user.value);
        if (itr == accounts.end()) {
            accounts.emplace(user, [&](auto& row) {
                row.owner = user;
                row.balance = quantity;
            });
        } else {
            accounts.modify(itr, eosio::same_payer, [&](auto& row) {
                row.balance += quantity;
            });
        }
    }

    [[eosio::action]]
    void withdraw(eosio::name user, eosio::asset quantity) {
        require_auth(user);
        eosio::check(quantity.is_valid() && quantity.amount > 0, "Invalid withdrawal quantity");

        accounts_table accounts(get_self(), get_self().value);
        auto itr = accounts.find(user.value);
        eosio::check(itr != accounts.end(), "User account not registered");
        eosio::check(itr->balance.amount >= quantity.amount, "Insufficient vault balance");

        accounts.modify(itr, eosio::same_payer, [&](auto& row) {
            row.balance -= quantity;
        });
    }


    bool get_protocol_health() {
        return true;
    }

    uint64_t compute_protocol_fee(uint64_t amount, uint64_t fee_bps) {
        if (amount == 0 || fee_bps == 0) return 0;
        return (amount * fee_bps) / 10000;
    }
};
