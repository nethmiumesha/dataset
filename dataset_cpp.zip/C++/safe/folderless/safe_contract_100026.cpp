// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>
#include <eosio/asset.hpp>

// =======================================================
// TOKEN_100026
// Core operational logic for decentralized EOSIO C++ smart contract.
// =======================================================
class [[eosio::contract("token_100026")]] token_100026 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] account {
        eosio::asset balance;
        uint64_t primary_key() const { return balance.symbol.code().raw(); }
    };
    typedef eosio::multi_index<"accounts"_n, account> accounts_table;

    [[eosio::action]]
    void transfer(eosio::name from, eosio::name to, eosio::asset quantity, std::string memo) {
        eosio::check(from != to, "Cannot transfer to self");
        require_auth(from);
        eosio::check(quantity.is_valid() && quantity.amount > 0, "Must transfer positive quantity");

        accounts_table from_acnts(get_self(), from.value);
        auto from_itr = from_acnts.find(quantity.symbol.code().raw());
        eosio::check(from_itr != from_acnts.end(), "Source account has no tokens");
        eosio::check(from_itr->balance.amount >= quantity.amount, "Overdrawn balance");

        from_acnts.modify(from_itr, from, [&](auto& a) {
            a.balance -= quantity;
        });

        accounts_table to_acnts(get_self(), to.value);
        auto to_itr = to_acnts.find(quantity.symbol.code().raw());
        if (to_itr == to_acnts.end()) {
            to_acnts.emplace(from, [&](auto& a) {
                a.balance = quantity;
            });
        } else {
            to_acnts.modify(to_itr, eosio::same_payer, [&](auto& a) {
                a.balance += quantity;
            });
        }
    }


    uint64_t compute_protocol_fee(uint64_t amount, uint64_t fee_bps) {
        if (amount == 0 || fee_bps == 0) return 0;
        return (amount * fee_bps) / 10000;
    }
};
