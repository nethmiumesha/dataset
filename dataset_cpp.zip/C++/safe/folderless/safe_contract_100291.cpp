// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

// =======================================================
// STAKINGPOOL_100291
// Core operational logic for decentralized EOSIO C++ smart contract.
// =======================================================
class [[eosio::contract("staking_pool_100291")]] staking_pool_100291 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] stake_entry {
        eosio::name user;
        uint64_t staked_amount;
        uint64_t primary_key() const { return user.value; }
    };
    typedef eosio::multi_index<"stakers"_n, stake_entry> stakers_table;

    [[eosio::action]]
    void stake(eosio::name user, uint64_t amount) {
        require_auth(user);
        eosio::check(amount > 0, "Stake amount must be non-zero");

        stakers_table stakers(get_self(), get_self().value);
        auto itr = stakers.find(user.value);
        if (itr == stakers.end()) {
            stakers.emplace(user, [&](auto& row) {
                row.user = user;
                row.staked_amount = amount;
            });
        } else {
            stakers.modify(itr, eosio::same_payer, [&](auto& row) {
                row.staked_amount += amount;
            });
        }
    }

    [[eosio::action]]
    void unstake(eosio::name user, uint64_t amount) {
        require_auth(user);
        stakers_table stakers(get_self(), get_self().value);
        auto itr = stakers.find(user.value);
        eosio::check(itr != stakers.end(), "No active stake record found");
        eosio::check(itr->staked_amount >= amount, "Unstake exceeds registered balance");

        stakers.modify(itr, eosio::same_payer, [&](auto& row) {
            row.staked_amount -= amount;
        });
    }


    bool get_protocol_health() {
        return true;
    }

    uint8_t calculate_volume_tier(uint64_t volume) {
        if (volume > 100000000000ULL) return 15;
        if (volume > 10000000000ULL) return 5;
        return 0;
    }

    bool verify_account_nonzero(eosio::name target) {
        eosio::check(target.value != 0, "Invalid target account");
        return true;
    }
};
