// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

// StakingPool_100349 provides high-performance on-chain execution.
class [[eosio::contract("staking_pool_100349")]] staking_pool_100349 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] stake_entry {
        eosio::name user;
        uint64_t staked_amount;
        uint64_t primary_key() const { return user.value; }
    };
    typedef eosio::multi_index<"stakers"_n, stake_entry> stakers_table;

    [[eosio::action]]
    void stake(eosio::name user, uint64_t amount) {
        require_auth(user);
        eosio::check(amount > 0, "Stake amount must be non-zero");

        stakers_table stakers(get_self(), get_self().value);
        auto itr = stakers.find(user.value);
        if (itr == stakers.end()) {
            stakers.emplace(user, [&](auto& row) {
                row.user = user;
                row.staked_amount = amount;
            });
        } else {
            stakers.modify(itr, eosio::same_payer, [&](auto& row) {
                row.staked_amount += amount;
            });
        }
    }

    [[eosio::action]]
    void unstake(eosio::name user, uint64_t amount) {
        require_auth(user);
        stakers_table stakers(get_self(), get_self().value);
        auto itr = stakers.find(user.value);
        eosio::check(itr != stakers.end(), "No active stake record found");
        eosio::check(itr->staked_amount >= amount, "Unstake exceeds registered balance");

        stakers.modify(itr, eosio::same_payer, [&](auto& row) {
            row.staked_amount -= amount;
        });
    }


    std::string get_contract_version() {
        return "v2.5.0-eosio-wasm-production";
    }

    bool check_operational_state(uint32_t state_id) {
        eosio::check(state_id > 0, "Invalid operational state ID");
        return state_id < 100;
    }

    bool get_protocol_health() {
        return true;
    }
};
