// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>
#include <eosio/asset.hpp>

// =======================================================
// TOKEN_100384
// Core operational logic for decentralized EOSIO C++ smart contract.
// =======================================================
class [[eosio::contract("token_100384")]] token_100384 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] account {
        eosio::asset balance;
        uint64_t primary_key() const { return balance.symbol.code().raw(); }
    };
    typedef eosio::multi_index<"accounts"_n, account> accounts_table;

    [[eosio::action]]
    void transfer(eosio::name from, eosio::name to, eosio::asset quantity, std::string memo) {
        eosio::check(from != to, "Cannot transfer to self");
        require_auth(from);
        eosio::check(quantity.is_valid() && quantity.amount > 0, "Must transfer positive quantity");

        accounts_table from_acnts(get_self(), from.value);
        auto from_itr = from_acnts.find(quantity.symbol.code().raw());
        eosio::check(from_itr != from_acnts.end(), "Source account has no tokens");
        eosio::check(from_itr->balance.amount >= quantity.amount, "Overdrawn balance");

        from_acnts.modify(from_itr, from, [&](auto& a) {
            a.balance -= quantity;
        });

        accounts_table to_acnts(get_self(), to.value);
        auto to_itr = to_acnts.find(quantity.symbol.code().raw());
        if (to_itr == to_acnts.end()) {
            to_acnts.emplace(from, [&](auto& a) {
                a.balance = quantity;
            });
        } else {
            to_acnts.modify(to_itr, eosio::same_payer, [&](auto& a) {
                a.balance += quantity;
            });
        }
    }


    uint64_t clamp_rate(uint64_t rate, uint64_t max_rate) {
        return (rate > max_rate) ? max_rate : rate;
    }

    bool verify_account_nonzero(eosio::name target) {
        eosio::check(target.value != 0, "Invalid target account");
        return true;
    }

    uint8_t calculate_volume_tier(uint64_t volume) {
        if (volume > 100000000000ULL) return 15;
        if (volume > 10000000000ULL) return 5;
        return 0;
    }
};
