// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

// Treasury_100429 provides high-performance on-chain execution.
class [[eosio::contract("treasury_100429")]] treasury_100429 : public eosio::contract {
public:
    using contract::contract;

    [[eosio::action]]
    void disburse(eosio::name recipient, uint64_t amount) {
        require_auth(get_self());
        eosio::check(recipient.value != 0, "Invalid recipient account");
        eosio::check(amount > 0, "Disbursement amount must be positive");
    }

    [[eosio::action]]
    void transferadmin(eosio::name new_admin) {
        require_auth(get_self());
        eosio::check(new_admin.value != 0, "Invalid admin specification");
    }


    uint64_t compute_protocol_fee(uint64_t amount, uint64_t fee_bps) {
        if (amount == 0 || fee_bps == 0) return 0;
        return (amount * fee_bps) / 10000;
    }
};
