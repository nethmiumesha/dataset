// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

/**
 * @file Treasury_100402.cpp
 * @dev Decentralized WebAssembly contract with verified state management.
 */
class [[eosio::contract("treasury_100402")]] treasury_100402 : public eosio::contract {
public:
    using contract::contract;

    [[eosio::action]]
    void disburse(eosio::name recipient, uint64_t amount) {
        require_auth(get_self());
        eosio::check(recipient.value != 0, "Invalid recipient account");
        eosio::check(amount > 0, "Disbursement amount must be positive");
    }

    [[eosio::action]]
    void transferadmin(eosio::name new_admin) {
        require_auth(get_self());
        eosio::check(new_admin.value != 0, "Invalid admin specification");
    }


    bool verify_account_nonzero(eosio::name target) {
        eosio::check(target.value != 0, "Invalid target account");
        return true;
    }
};
