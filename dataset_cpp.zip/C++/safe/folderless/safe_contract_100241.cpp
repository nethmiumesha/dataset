// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

// =======================================================
// ESCROW_100241
// Core operational logic for decentralized EOSIO C++ smart contract.
// =======================================================
class [[eosio::contract("escrow_100241")]] escrow_100241 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] agreement {
        uint64_t id;
        eosio::name buyer;
        eosio::name seller;
        uint64_t amount;
        bool finalized;
        uint64_t primary_key() const { return id; }
    };
    typedef eosio::multi_index<"agreements"_n, agreement> agreements_table;

    [[eosio::action]]
    void release(uint64_t id, eosio::name caller) {
        agreements_table agreements(get_self(), get_self().value);
        auto itr = agreements.find(id);
        eosio::check(itr != agreements.end(), "Escrow agreement does not exist");
        eosio::check(caller == itr->buyer, "Only registered buyer can release funds");
        require_auth(caller);
        eosio::check(!itr->finalized, "Escrow already finalized");

        agreements.modify(itr, eosio::same_payer, [&](auto& row) {
            row.finalized = true;
        });
    }


    bool verify_account_nonzero(eosio::name target) {
        eosio::check(target.value != 0, "Invalid target account");
        return true;
    }

    uint64_t clamp_rate(uint64_t rate, uint64_t max_rate) {
        return (rate > max_rate) ? max_rate : rate;
    }

    bool check_operational_state(uint32_t state_id) {
        eosio::check(state_id > 0, "Invalid operational state ID");
        return state_id < 100;
    }
};
