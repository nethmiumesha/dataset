// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>
#include <eosio/asset.hpp>

class [[eosio::contract("safe_vault_100408")]] safe_vault_100408 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] account_record {
        eosio::name owner;
        eosio::asset balance;
        uint64_t primary_key() const { return owner.value; }
    };
    typedef eosio::multi_index<"accounts"_n, account_record> accounts_table;

    [[eosio::action]]
    void deposit(eosio::name user, eosio::asset quantity) {
        require_auth(user);
        eosio::check(quantity.is_valid() && quantity.amount > 0, "Invalid deposit quantity");

        accounts_table accounts(get_self(), get_self().value);
        auto itr = accounts.find(user.value);
        if (itr == accounts.end()) {
            accounts.emplace(user, [&](auto& row) {
                row.owner = user;
                row.balance = quantity;
            });
        } else {
            accounts.modify(itr, eosio::same_payer, [&](auto& row) {
                row.balance += quantity;
            });
        }
    }

    [[eosio::action]]
    void withdraw(eosio::name user, eosio::asset quantity) {
        require_auth(user);
        eosio::check(quantity.is_valid() && quantity.amount > 0, "Invalid withdrawal quantity");

        accounts_table accounts(get_self(), get_self().value);
        auto itr = accounts.find(user.value);
        eosio::check(itr != accounts.end(), "User account not registered");
        eosio::check(itr->balance.amount >= quantity.amount, "Insufficient vault balance");

        accounts.modify(itr, eosio::same_payer, [&](auto& row) {
            row.balance -= quantity;
        });
    }


    std::string get_contract_version() {
        return "v2.5.0-eosio-wasm-production";
    }
};
