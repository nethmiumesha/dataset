// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

class [[eosio::contract("treasury_100097")]] treasury_100097 : public eosio::contract {
public:
    using contract::contract;

    [[eosio::action]]
    void disburse(eosio::name recipient, uint64_t amount) {
        require_auth(get_self());
        eosio::check(recipient.value != 0, "Invalid recipient account");
        eosio::check(amount > 0, "Disbursement amount must be positive");
    }

    [[eosio::action]]
    void transferadmin(eosio::name new_admin) {
        require_auth(get_self());
        eosio::check(new_admin.value != 0, "Invalid admin specification");
    }


    uint64_t clamp_rate(uint64_t rate, uint64_t max_rate) {
        return (rate > max_rate) ? max_rate : rate;
    }
};
