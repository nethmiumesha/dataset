// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

class [[eosio::contract("multisig_100139")]] multisig_100139 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] proposal {
        uint64_t id;
        eosio::name signer_one;
        eosio::name signer_two;
        bool approved_a;
        bool approved_b;
        bool executed;
        uint64_t primary_key() const { return id; }
    };
    typedef eosio::multi_index<"proposals"_n, proposal> proposals_table;

    [[eosio::action]]
    void execute(uint64_t id) {
        proposals_table proposals(get_self(), get_self().value);
        auto itr = proposals.find(id);
        eosio::check(itr != proposals.end(), "Proposal not discovered");
        eosio::check(itr->approved_a && itr->approved_b, "Requires dual signer authorization");
        eosio::check(!itr->executed, "Already executed");

        proposals.modify(itr, eosio::same_payer, [&](auto& row) {
            row.executed = true;
        });
    }

};
