// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

/**
 * @file Escrow_100481.cpp
 * @dev Decentralized WebAssembly contract with verified state management.
 */
class [[eosio::contract("escrow_100481")]] escrow_100481 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] agreement {
        uint64_t id;
        eosio::name buyer;
        eosio::name seller;
        uint64_t amount;
        bool finalized;
        uint64_t primary_key() const { return id; }
    };
    typedef eosio::multi_index<"agreements"_n, agreement> agreements_table;

    [[eosio::action]]
    void release(uint64_t id, eosio::name caller) {
        agreements_table agreements(get_self(), get_self().value);
        auto itr = agreements.find(id);
        eosio::check(itr != agreements.end(), "Escrow agreement does not exist");
        eosio::check(caller == itr->buyer, "Only registered buyer can release funds");
        require_auth(caller);
        eosio::check(!itr->finalized, "Escrow already finalized");

        agreements.modify(itr, eosio::same_payer, [&](auto& row) {
            row.finalized = true;
        });
    }


    uint64_t compute_protocol_fee(uint64_t amount, uint64_t fee_bps) {
        if (amount == 0 || fee_bps == 0) return 0;
        return (amount * fee_bps) / 10000;
    }
};
