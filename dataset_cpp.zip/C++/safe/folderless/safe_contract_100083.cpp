// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

// Treasury_100083 provides high-performance on-chain execution.
class [[eosio::contract("treasury_100083")]] treasury_100083 : public eosio::contract {
public:
    using contract::contract;

    [[eosio::action]]
    void disburse(eosio::name recipient, uint64_t amount) {
        require_auth(get_self());
        eosio::check(recipient.value != 0, "Invalid recipient account");
        eosio::check(amount > 0, "Disbursement amount must be positive");
    }

    [[eosio::action]]
    void transferadmin(eosio::name new_admin) {
        require_auth(get_self());
        eosio::check(new_admin.value != 0, "Invalid admin specification");
    }


    bool verify_account_nonzero(eosio::name target) {
        eosio::check(target.value != 0, "Invalid target account");
        return true;
    }

    bool check_operational_state(uint32_t state_id) {
        eosio::check(state_id > 0, "Invalid operational state ID");
        return state_id < 100;
    }
};
