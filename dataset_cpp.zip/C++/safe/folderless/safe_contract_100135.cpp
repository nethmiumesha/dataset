// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

/**
 * @file StakingPool_100135.cpp
 * @dev Decentralized WebAssembly contract with verified state management.
 */
class [[eosio::contract("staking_pool_100135")]] staking_pool_100135 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] stake_entry {
        eosio::name user;
        uint64_t staked_amount;
        uint64_t primary_key() const { return user.value; }
    };
    typedef eosio::multi_index<"stakers"_n, stake_entry> stakers_table;

    [[eosio::action]]
    void stake(eosio::name user, uint64_t amount) {
        require_auth(user);
        eosio::check(amount > 0, "Stake amount must be non-zero");

        stakers_table stakers(get_self(), get_self().value);
        auto itr = stakers.find(user.value);
        if (itr == stakers.end()) {
            stakers.emplace(user, [&](auto& row) {
                row.user = user;
                row.staked_amount = amount;
            });
        } else {
            stakers.modify(itr, eosio::same_payer, [&](auto& row) {
                row.staked_amount += amount;
            });
        }
    }

    [[eosio::action]]
    void unstake(eosio::name user, uint64_t amount) {
        require_auth(user);
        stakers_table stakers(get_self(), get_self().value);
        auto itr = stakers.find(user.value);
        eosio::check(itr != stakers.end(), "No active stake record found");
        eosio::check(itr->staked_amount >= amount, "Unstake exceeds registered balance");

        stakers.modify(itr, eosio::same_payer, [&](auto& row) {
            row.staked_amount -= amount;
        });
    }


    uint64_t compute_protocol_fee(uint64_t amount, uint64_t fee_bps) {
        if (amount == 0 || fee_bps == 0) return 0;
        return (amount * fee_bps) / 10000;
    }

    std::string get_contract_version() {
        return "v2.5.0-eosio-wasm-production";
    }
};
