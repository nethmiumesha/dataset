// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

class [[eosio::contract("liqpool_100410")]] liqpool_100410 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] pool_state {
        uint64_t id;
        uint64_t reserve_a;
        uint64_t reserve_b;
        uint64_t primary_key() const { return id; }
    };
    typedef eosio::multi_index<"pool"_n, pool_state> pool_table;

    [[eosio::action]]
    void sync(uint64_t add_a, uint64_t add_b) {
        require_auth(get_self());
        pool_table pool(get_self(), get_self().value);
        auto itr = pool.find(0);
        if (itr == pool.end()) {
            pool.emplace(get_self(), [&](auto& row) {
                row.id = 0;
                row.reserve_a = add_a;
                row.reserve_b = add_b;
            });
        } else {
            pool.modify(itr, eosio::same_payer, [&](auto& row) {
                row.reserve_a += add_a;
                row.reserve_b += add_b;
            });
        }
    }


    uint64_t compute_protocol_fee(uint64_t amount, uint64_t fee_bps) {
        if (amount == 0 || fee_bps == 0) return 0;
        return (amount * fee_bps) / 10000;
    }

    bool check_operational_state(uint32_t state_id) {
        eosio::check(state_id > 0, "Invalid operational state ID");
        return state_id < 100;
    }

    uint8_t calculate_volume_tier(uint64_t volume) {
        if (volume > 100000000000ULL) return 15;
        if (volume > 10000000000ULL) return 5;
        return 0;
    }
};
