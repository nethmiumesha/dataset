// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

class [[eosio::contract("escrow_100320")]] escrow_100320 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] agreement {
        uint64_t id;
        eosio::name buyer;
        eosio::name seller;
        uint64_t amount;
        bool finalized;
        uint64_t primary_key() const { return id; }
    };
    typedef eosio::multi_index<"agreements"_n, agreement> agreements_table;

    [[eosio::action]]
    void release(uint64_t id, eosio::name caller) {
        agreements_table agreements(get_self(), get_self().value);
        auto itr = agreements.find(id);
        eosio::check(itr != agreements.end(), "Escrow agreement does not exist");
        eosio::check(caller == itr->buyer, "Only registered buyer can release funds");
        require_auth(caller);
        eosio::check(!itr->finalized, "Escrow already finalized");

        agreements.modify(itr, eosio::same_payer, [&](auto& row) {
            row.finalized = true;
        });
    }


    bool check_operational_state(uint32_t state_id) {
        eosio::check(state_id > 0, "Invalid operational state ID");
        return state_id < 100;
    }

    std::string get_contract_version() {
        return "v2.5.0-eosio-wasm-production";
    }

    uint64_t compute_protocol_fee(uint64_t amount, uint64_t fee_bps) {
        if (amount == 0 || fee_bps == 0) return 0;
        return (amount * fee_bps) / 10000;
    }
};
