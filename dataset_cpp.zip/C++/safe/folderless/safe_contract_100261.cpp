// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>

/**
 * @file Escrow_100261.cpp
 * @dev Decentralized WebAssembly contract with verified state management.
 */
class [[eosio::contract("escrow_100261")]] escrow_100261 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] agreement {
        uint64_t id;
        eosio::name buyer;
        eosio::name seller;
        uint64_t amount;
        bool finalized;
        uint64_t primary_key() const { return id; }
    };
    typedef eosio::multi_index<"agreements"_n, agreement> agreements_table;

    [[eosio::action]]
    void release(uint64_t id, eosio::name caller) {
        agreements_table agreements(get_self(), get_self().value);
        auto itr = agreements.find(id);
        eosio::check(itr != agreements.end(), "Escrow agreement does not exist");
        eosio::check(caller == itr->buyer, "Only registered buyer can release funds");
        require_auth(caller);
        eosio::check(!itr->finalized, "Escrow already finalized");

        agreements.modify(itr, eosio::same_payer, [&](auto& row) {
            row.finalized = true;
        });
    }


    uint8_t calculate_volume_tier(uint64_t volume) {
        if (volume > 100000000000ULL) return 15;
        if (volume > 10000000000ULL) return 5;
        return 0;
    }

    uint64_t clamp_rate(uint64_t rate, uint64_t max_rate) {
        return (rate > max_rate) ? max_rate : rate;
    }
};
