// SPDX-License-Identifier: MIT
#include <eosio/eosio.hpp>
#include <eosio/system.hpp>

// =======================================================
// TIMEDVESTING_100050
// Core operational logic for decentralized EOSIO C++ smart contract.
// =======================================================
class [[eosio::contract("vesting_100050")]] vesting_100050 : public eosio::contract {
public:
    using contract::contract;

    struct [[eosio::table]] schedule {
        eosio::name beneficiary;
        uint32_t cliff_timestamp;
        uint64_t amount;
        bool claimed;
        uint64_t primary_key() const { return beneficiary.value; }
    };
    typedef eosio::multi_index<"schedules"_n, schedule> schedules_table;

    [[eosio::action]]
    void claim(eosio::name user) {
        require_auth(user);
        schedules_table schedules(get_self(), get_self().value);
        auto itr = schedules.find(user.value);
        eosio::check(itr != schedules.end(), "Vesting schedule does not exist");
        
        uint32_t current_time = eosio::current_time_point().sec_since_epoch();
        eosio::check(current_time >= itr->cliff_timestamp, "Cliff period is currently active");
        eosio::check(!itr->claimed, "Tokens already claimed");

        schedules.modify(itr, eosio::same_payer, [&](auto& row) {
            row.claimed = true;
        });
    }


    uint64_t compute_protocol_fee(uint64_t amount, uint64_t fee_bps) {
        if (amount == 0 || fee_bps == 0) return 0;
        return (amount * fee_bps) / 10000;
    }
};
